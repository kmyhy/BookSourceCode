//
//  ViewController.m
//  CorePlotPieTest
//
//  Created by chen neng on 12-7-28.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController
@synthesize label;


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	model = [[NSMutableArray alloc]initWithObjects:
             [NSNumber numberWithDouble:10.5], 
             [NSNumber numberWithDouble:27.0], 
             [NSNumber numberWithDouble:62.5], nil];
    
    // Create pieChart from theme
	pieChart = [[CPTXYGraph alloc] initWithFrame:CGRectZero];
	CPTTheme *theme = [CPTTheme themeNamed:kCPTPlainWhiteTheme];
	[pieChart applyTheme:theme];
	[(CPTGraphHostingView*)self.view setHostedGraph:pieChart];
        
	pieChart.axisSet = nil;
    
	CPTMutableTextStyle *whiteText = [CPTMutableTextStyle textStyle];
	whiteText.color = [CPTColor blackColor];
    
	pieChart.titleTextStyle = whiteText;
	pieChart.title			= @"Graph Title";
    
	// Add pie chart
	CPTPieChart *piePlot = [[CPTPieChart alloc] init];
	piePlot.dataSource		= self;
	piePlot.pieRadius		= 131.0;
	piePlot.identifier		= @"Pie Chart 1";
	piePlot.startAngle		= M_PI_4;
	piePlot.sliceDirection	= CPTPieDirectionCounterClockwise;
	piePlot.centerAnchor	= CGPointMake(0.5, 0.38);
	piePlot.borderLineStyle = [CPTLineStyle lineStyle];
	piePlot.delegate		= self;
	[pieChart addPlot:piePlot];
	[piePlot release];
    
    // Add Legend 
    CPTLegend *theLegend = [CPTLegend legendWithGraph:pieChart];
	theLegend.numberOfColumns = 2;
	theLegend.fill			  = [CPTFill fillWithColor:[CPTColor lightGrayColor]];
	theLegend.borderLineStyle = [CPTLineStyle lineStyle];
	theLegend.cornerRadius	  = 5.0;
    
	pieChart.legend = theLegend;
    
	pieChart.legendAnchor		 = CPTRectAnchorTopRight;
	pieChart.legendDisplacement = CGPointMake(-30.0, -30.0);

}

- (void)viewDidUnload
{
    [self setLabel:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}
#pragma mark -
#pragma mark Plot Data Source Methods

-(NSUInteger)numberOfRecordsForPlot:(CPTPlot *)plot
{
	return [model count];
}

-(NSNumber *)numberForPlot:(CPTPlot *)plot field:(NSUInteger)fieldEnum recordIndex:(NSUInteger)index
{    
	return [model objectAtIndex:index];

}

-(CPTLayer *)dataLabelForPlot:(CPTPlot *)plot recordIndex:(NSUInteger)index
{
    float f=((NSNumber*)[model objectAtIndex:index]).floatValue;
	CPTTextLayer *_label			   = [[CPTTextLayer alloc] initWithText:[NSString stringWithFormat:@"%.1f%%",f]];
	CPTMutableTextStyle *textStyle = [_label.textStyle mutableCopy];
    
	textStyle.color = [CPTColor lightGrayColor];
	_label.textStyle = textStyle;
	[textStyle release];
	return [_label autorelease];
}       

-(CGFloat)radialOffsetForPieChart:(CPTPieChart *)piePlot recordIndex:(NSUInteger)index
{
	return (index==1?10:0);
}

-(NSString *)legendTitleForPieChart:(CPTPieChart *)pieChart recordIndex:(NSUInteger)index{
    switch (index) {
        case 0:
            return @"其他";
        case 1:
            return @"Google Android";
        case 2:
            return @"Apple iOS";
        default:
            return nil;
    }
}

#pragma mark -
#pragma mark Delegate Methods

-(void)pieChart:(CPTPieChart *)plot sliceWasSelectedAtRecordIndex:(NSUInteger)index
{
    [self.view bringSubviewToFront:label];
    
    float f=((NSNumber*)[model objectAtIndex:index]).floatValue;
	NSString *text = [self legendTitleForPieChart:plot recordIndex:index];
    text=[NSString stringWithFormat:@"%@:%.1f%%", text,f];
    label.text=text;
    label.alpha=0;
    
    // Animate the change
    [CATransaction begin];
    CGAffineTransform textTransform = CGAffineTransformMake(1.0, 0.0, 0.0, -1.0,0.0, 0.0);
    [label.layer setAffineTransform:textTransform];
    // UIView exposes this as alpha where as CALayer exposes this as opacity
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"opacity"];
    animation.duration			= 1.0f;
    // set removedOnCompletion=YES - the value would be set back to origin 0 
    // when animation performed completely. 
    animation.removedOnCompletion = YES;
    animation.fillMode			= kCAFillModeForwards;
    animation.toValue				= [NSNumber numberWithFloat:1.0];
    [label.layer addAnimation:animation forKey:@"OutEase"];
    [CATransaction commit];
    
}


- (void)dealloc {
    [pieChart release];
    [model release];
    [label release];
    [super dealloc];
}
@end
