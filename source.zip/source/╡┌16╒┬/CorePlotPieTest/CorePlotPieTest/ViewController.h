//
//  ViewController.h
//  CorePlotPieTest
//
//  Created by chen neng on 12-7-28.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CorePlot-CocoaTouch.h"


@interface ViewController : UIViewController<CPTPieChartDataSource,CPTPlotSpaceDelegate, CPTPieChartDelegate>{
    CPTXYGraph *pieChart;
	NSMutableArray *model;
}

@property (retain, nonatomic) IBOutlet UILabel *label;

@end
