//
//  ViewController.h
//  CorePlotBarTest
//
//  Created by chen neng on 12-7-27.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CorePlot-CocoaTouch.h"
@interface ViewController : UIViewController<CPTPlotDataSource>{
    NSMutableArray* points;
    CPTXYGraph* graph;
    CPTBarPlot* barPlot;
}
@property (retain, nonatomic) IBOutlet CPTGraphHostingView *hostingView;
- (IBAction)loadData:(id)sender;

@end
