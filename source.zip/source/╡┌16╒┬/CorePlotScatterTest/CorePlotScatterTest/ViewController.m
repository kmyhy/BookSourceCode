//
//  ViewController.m
//  CorePlotScatterTest
//
//  Created by chen neng on 12-7-26.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController

-(id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self=[super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        points=[[NSMutableArray alloc]init];
        // 随机生成一些点
        NSUInteger i;
        for ( i = 0; i < 60; i++ ) {
            id x = [NSNumber numberWithFloat:1 + i * 0.05];
            id y = [NSNumber numberWithFloat:1.2 * rand() / (float)RAND_MAX + 1.2];
            [points addObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:x, @"x", y, @"y", nil]];
        }

    }
    return  self;
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // 创建Graph对象并加入到hostingView中
	graph = [[CPTXYGraph alloc] initWithFrame:CGRectZero];
    // 使用默认主题，主题主要包含以下样式：背景色和坐标轴样式
    CPTTheme *theme = [CPTTheme themeNamed:kCPTPlainWhiteTheme];
	[graph applyTheme:theme];

    CPTGraphHostingView *hostingView = (CPTGraphHostingView *)self.view;
    hostingView.hostedGraph		= graph;
    
    // 设置绘图空间
    CPTXYPlotSpace *plotSpace = (CPTXYPlotSpace *)graph.defaultPlotSpace;
	plotSpace.allowsUserInteraction = YES;
    // 设置x,y坐标范围
	plotSpace.xRange				= [CPTPlotRange plotRangeWithLocation:CPTDecimalFromFloat(1.0) length:CPTDecimalFromFloat(2.0)];
	plotSpace.yRange				= [CPTPlotRange plotRangeWithLocation:CPTDecimalFromFloat(1.0) length:CPTDecimalFromFloat(3.0)];
    
    // 坐标系
	CPTXYAxisSet *axisSet = (CPTXYAxisSet *)graph.axisSet;
	CPTXYAxis *x		  = axisSet.xAxis;
    // 大刻度单位：0.5
	x.majorIntervalLength		  = CPTDecimalFromString(@"0.5");
    // 坐标原点在 2
	x.orthogonalCoordinateDecimal = CPTDecimalFromString(@"2");
    // 每个大刻度单位中有2个小刻度
	x.minorTicksPerInterval		  = 2;
    // 设定 label 显示的排除范围。以下排除范围将导致x坐标的2、1、3 label不被显示。
	NSArray *exclusionRanges = [NSArray arrayWithObjects:
								[CPTPlotRange plotRangeWithLocation:CPTDecimalFromFloat(1.99) length:CPTDecimalFromFloat(0.02)],
								[CPTPlotRange plotRangeWithLocation:CPTDecimalFromFloat(0.99) length:CPTDecimalFromFloat(0.02)],
								[CPTPlotRange plotRangeWithLocation:CPTDecimalFromFloat(2.99) length:CPTDecimalFromFloat(0.02)],
								nil];
	x.labelExclusionRanges = exclusionRanges;
    
	CPTXYAxis *y = axisSet.yAxis;
	y.majorIntervalLength		  = CPTDecimalFromString(@"0.5");
	y.minorTicksPerInterval		  = 5;
	y.orthogonalCoordinateDecimal = CPTDecimalFromString(@"2");
	exclusionRanges				  = [NSArray arrayWithObjects:
									 [CPTPlotRange plotRangeWithLocation:CPTDecimalFromFloat(1.99) length:CPTDecimalFromFloat(0.02)],
									 [CPTPlotRange plotRangeWithLocation:CPTDecimalFromFloat(0.99) length:CPTDecimalFromFloat(0.02)],
									 [CPTPlotRange plotRangeWithLocation:CPTDecimalFromFloat(3.99) length:CPTDecimalFromFloat(0.02)],
									 nil];
	y.labelExclusionRanges = exclusionRanges;
	y.delegate			   = self;// y坐标使用了自定义的tick标签

    // 创建散点图
	CPTScatterPlot *boundLinePlot  = [[[CPTScatterPlot alloc] init] autorelease];
    // 创建Mutable的线型，只有Mutable的线型对象是可以修改的
	CPTMutableLineStyle *lineStyle = [CPTMutableLineStyle lineStyle];
    // 尖角限制为1。把线段中线交点到尖角处四等分，只留下最下面1/4份，上端3/4份截去
	lineStyle.miterLimit		= 1.0f;
	lineStyle.lineWidth			= 3.0f;
	lineStyle.lineColor			= [CPTColor blueColor];
	boundLinePlot.dataLineStyle = lineStyle;
	boundLinePlot.identifier	= @"Blue Plot";
	boundLinePlot.dataSource	= self;
	[graph addPlot:boundLinePlot];
    
    // 创建颜色渐变
	CPTColor *color1	   = [CPTColor colorWithComponentRed:0.3 green:0.3 blue:1.0 alpha:0.8];
	CPTGradient *areaGradient1 = [CPTGradient gradientWithBeginningColor:color1 endingColor:[CPTColor clearColor]];
    // 设置渐变方向。从X轴正轴方向开始旋转 n 度。n为正，反时针旋转，n为负，正时针旋转。
	areaGradient1.angle = -90.0f;
    
    // 创建颜色填充区域
	CPTFill *areaFill = [CPTFill fillWithGradient:areaGradient1];
	boundLinePlot.areaFill		= areaFill;
	boundLinePlot.areaBaseValue = [[NSDecimalNumber zero] decimalValue];
    
    // 在数据点处绘制节点符号：一个圆圈
	CPTMutableLineStyle *symbolLineStyle = [CPTMutableLineStyle lineStyle];
    // 圆圈用黑色绘制
	symbolLineStyle.lineColor = [CPTColor blackColor];
	CPTPlotSymbol *plotSymbol = [CPTPlotSymbol ellipsePlotSymbol];
    // 用蓝色填充
	plotSymbol.fill			 = [CPTFill fillWithColor:[CPTColor blueColor]];
	plotSymbol.lineStyle	 = symbolLineStyle;
	plotSymbol.size			 = CGSizeMake(10.0, 10.0);
    // 设定为散点图的节点符号
	boundLinePlot.plotSymbol = plotSymbol;
    
    // 为散点图做一个渐现特效
	boundLinePlot.opacity = 0.0f;
    
	CABasicAnimation *fadeInAnimation = [CABasicAnimation animationWithKeyPath:@"opacity"];
	fadeInAnimation.duration			= 1.0f;
	fadeInAnimation.removedOnCompletion = NO;
	fadeInAnimation.fillMode			= kCAFillModeForwards;
	fadeInAnimation.toValue				= [NSNumber numberWithFloat:1.0];
	[boundLinePlot addAnimation:fadeInAnimation forKey:@"animateOpacity"];
    
//    [NSTimer scheduledTimerWithTimeInterval:2.0 target:self selector:@selector(changePlotRange) userInfo:nil repeats:YES];

}
-(void)changePlotRange
{
    CPTXYPlotSpace *plotSpace = (CPTXYPlotSpace *)graph.defaultPlotSpace;
	plotSpace.xRange = [CPTPlotRange plotRangeWithLocation:CPTDecimalFromFloat(0.0) length:CPTDecimalFromFloat(3.0 + 2.0 * rand() / RAND_MAX)];
	plotSpace.yRange = [CPTPlotRange plotRangeWithLocation:CPTDecimalFromFloat(0.0) length:CPTDecimalFromFloat(3.0 + 2.0 * rand() / RAND_MAX)];
}
- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}
#pragma mark Plot Data Source Methods

-(NSUInteger)numberOfRecordsForPlot:(CPTPlot *)plot
{
	return [points count];
}

-(NSNumber *)numberForPlot:(CPTPlot *)plot field:(NSUInteger)fieldEnum recordIndex:(NSUInteger)index
{
	NSString *key = (fieldEnum == CPTScatterPlotFieldX ? @"x" : @"y");
	NSNumber *num = [[points objectAtIndex:index] valueForKey:key];
    
	return num;
}

#pragma mark -
#pragma mark Axis Delegate Methods
-(BOOL)axis:(CPTAxis *)axis shouldUpdateAxisLabelsAtLocations:(NSSet *)locations
// 给每个大刻度创建一个自定义标签，对于小刻度使用shouldUpdateMinorAxisLabelsAtLocations方法
{
	static CPTTextStyle *positiveStyle = nil;
	static CPTTextStyle *negativeStyle = nil;
    
	NSNumberFormatter *formatter = axis.labelFormatter;
	CGFloat labelOffset			 = axis.labelOffset;
	NSDecimalNumber *zero		 = [NSDecimalNumber zero];
    
	NSMutableSet *newLabels = [NSMutableSet set];
    // 遍历坐标轴的所有标签所处的刻度数值
	for ( NSDecimalNumber *tickLocation in locations ) {
		CPTTextStyle *theLabelTextStyle;// 字型，包括：字体名、文字、颜色、对齐方式、大小
        
		if ( [tickLocation isGreaterThanOrEqualTo:zero] ) {// 0 以上刻度标签显示绿色
			if ( !positiveStyle ) {
				CPTMutableTextStyle *newStyle = [axis.labelTextStyle mutableCopy];
				newStyle.color = [CPTColor greenColor];
				positiveStyle  = newStyle;
			}
			theLabelTextStyle = positiveStyle;
		}else {// 0 以下刻度的标签显示为红色
			if ( !negativeStyle ) {
				CPTMutableTextStyle *newStyle = [axis.labelTextStyle mutableCopy];
				newStyle.color = [CPTColor redColor];
				negativeStyle  = newStyle;
			}
			theLabelTextStyle = negativeStyle;
		}
        // 取原来的刻度值，以原有字型写在文字层上
		NSString *labelString		= [formatter stringForObjectValue:tickLocation];
		CPTTextLayer *newLabelLayer = [[CPTTextLayer alloc] initWithText:labelString style:theLabelTextStyle];
        
        // 用文字层创建一个轴标签，数值、偏移位置都不变
		CPTAxisLabel *newLabel = [[CPTAxisLabel alloc] initWithContentLayer:newLabelLayer];
		newLabel.tickLocation = tickLocation.decimalValue;
		newLabel.offset		  = labelOffset;
        
		[newLabels addObject:newLabel];
        
		[newLabel release];
		[newLabelLayer release];
	}
    
	axis.axisLabels = newLabels;
    // 如果需要应用 CPTAxis 的默认行为，返回yes
	return NO;
}
-(void)dealloc{
    [graph release];
    [points release];
    [super release];
}

@end
