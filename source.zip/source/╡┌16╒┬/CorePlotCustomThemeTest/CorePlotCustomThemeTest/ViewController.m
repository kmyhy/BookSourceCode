//
//  ViewController.m
//  CorePlotBarTest
//
//  Created by chen neng on 12-7-27.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import "ViewController.h"
#import "MyTheme.h"

@implementation ViewController
@synthesize hostingView;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
-(void)addPoint:(NSDictionary*)point{
    [points addObject:point];
    CPTBarPlot *plot=(CPTBarPlot*)[graph plotWithIdentifier:@"Bar Plot"];
    [plot performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:NO];
}
static dispatch_source_t timer; 
static int max_bar_num=16;
- (IBAction)loadData:(id)sender {
    points=[[NSMutableArray alloc]init];
    
    if(timer) dispatch_source_cancel(timer);
    timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0));  
    __block int i=0;
    dispatch_source_set_timer(timer, DISPATCH_TIME_NOW, 1ull * NSEC_PER_SEC, 0);  
    dispatch_source_set_event_handler(timer, ^{ 
        i++;
        if (i<max_bar_num) {
            id x = (NSDecimalNumber *)[NSDecimalNumber numberWithUnsignedInteger:i];
            id y = (NSDecimalNumber *)[NSDecimalNumber numberWithUnsignedInteger:(i + 1) * (i + 1)];
            NSDictionary* point=[NSDictionary dictionaryWithObjectsAndKeys:x, @"x", y, @"y", nil];
            [self addPoint:point];
        }else{
            NSLog(@"timer stop!");
            barPlot.barWidthScale=1.2;
            CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"barWidthScale"];
            animation.duration			= 1.0f;
            animation.removedOnCompletion = YES;
            animation.fillMode			= kCAFillModeForwards;
            animation.toValue				= [NSNumber numberWithFloat:1.0/1.2f];
            [barPlot addAnimation:animation forKey:@"animateScale"];
            dispatch_source_cancel(timer);
        }
        
    });  
    dispatch_resume(timer); 
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	graph = [[CPTXYGraph alloc] initWithFrame:CGRectZero];
	MyTheme *theme = [[[MyTheme alloc]init]autorelease];
	[graph applyTheme:theme];
	[self.hostingView setHostedGraph:graph];
    
    CPTXYPlotSpace *plotSpace = (CPTXYPlotSpace *)graph.defaultPlotSpace;
    plotSpace.allowsUserInteraction = YES; // 允许拖动及缩放
	plotSpace.yRange = [CPTPlotRange plotRangeWithLocation:CPTDecimalFromFloat(0.0f) length:CPTDecimalFromFloat(300.0f)];
	plotSpace.xRange = [CPTPlotRange plotRangeWithLocation:CPTDecimalFromFloat(0.0f) length:CPTDecimalFromFloat(16.0f)];
    
    // 绘图区左边和下边腾出一些空间，以便显示坐标轴的标签及标题
//    graph.plotAreaFrame.paddingLeft	 = 70.0;
//	graph.plotAreaFrame.paddingTop	 = 20.0;
//	graph.plotAreaFrame.paddingRight	 = 20.0;
//	graph.plotAreaFrame.paddingBottom = 80.0;
    
    // 坐标系
	CPTXYAxisSet *axisSet = (CPTXYAxisSet *)graph.axisSet;
	CPTXYAxis *x		  = axisSet.xAxis;
    x.axisConstraints=[CPTConstraints constraintWithUpperOffset:50];
	x.majorIntervalLength		  = CPTDecimalFromString(@"5");
 	x.orthogonalCoordinateDecimal = CPTDecimalFromString(@"0");
    x.title=@"X Axis";
    x.minorTicksPerInterval		  = 2;
    x.titleLocation				  = CPTDecimalFromFloat(7.5f);
	x.titleOffset				  = 55.0f;
    // 设定 label 显示的排除范围。以下排除范围将导致x坐标的2、1、3 label不被显示。
	NSArray *exclusionRanges = [NSArray arrayWithObjects:
								[CPTPlotRange plotRangeWithLocation:CPTDecimalFromFloat(-0.02) length:CPTDecimalFromFloat(0.02)],nil];
	x.labelExclusionRanges = exclusionRanges;
    
	CPTXYAxis *y = axisSet.yAxis;
    y.axisConstraints=[CPTConstraints constraintWithUpperOffset:50];
	y.majorIntervalLength		  = CPTDecimalFromString(@"50");
	y.orthogonalCoordinateDecimal = CPTDecimalFromString(@"0");
	y.title						  = @"Y Axis";
	y.titleOffset				  = 45.0f;
    x.minorTicksPerInterval		  = 4;
	y.titleLocation				  = CPTDecimalFromFloat(150.0f);
	exclusionRanges				  = [NSArray arrayWithObjects:
									 [CPTPlotRange plotRangeWithLocation:CPTDecimalFromFloat(-0.02) length:CPTDecimalFromFloat(0.02)],nil];
	y.labelExclusionRanges = exclusionRanges;

    
    barPlot = [CPTBarPlot tubularBarPlotWithColor:[CPTColor blueColor] horizontalBars:NO];
	barPlot.baseValue  = CPTDecimalFromString(@"15");
	    // 创建颜色渐变
	CPTColor *color1	   = [CPTColor colorWithComponentRed:0.3 green:0.3 blue:1.0 alpha:0.8];
	CPTGradient *areaGradient1 = [CPTGradient gradientWithBeginningColor:color1 endingColor:[CPTColor clearColor]];
    // 设置渐变方向。从X轴正轴方向开始旋转 n 度。n为正，反时针旋转，n为负，正时针旋转。
	areaGradient1.angle = -90.0f;
    // 创建颜色填充区域
	CPTFill *areaFill = [CPTFill fillWithGradient:areaGradient1];
    barPlot.fill=areaFill;
    CPTMutableLineStyle *lineStyle1 = [CPTMutableLineStyle lineStyle];
 	lineStyle1.lineWidth			= 1.0f;
	lineStyle1.lineColor			= [CPTColor blueColor];
    barPlot.lineStyle=lineStyle1;
    barPlot.dataSource = self;
    
    CPTMutableTextStyle* textStyle=[CPTMutableTextStyle textStyle];
    textStyle.color=[CPTColor greenColor];
    textStyle.fontSize=10;
    barPlot.labelTextStyle=textStyle;
    barPlot.labelRotation=M_PI/4;
    

	barPlot.barOffset  = CPTDecimalFromFloat(-0.25f);
	barPlot.identifier = @"Bar Plot";
	[graph addPlot:barPlot toPlotSpace:plotSpace];
}
#pragma mark Plot Data Source Methods

-(NSUInteger)numberOfRecordsForPlot:(CPTPlot *)plot
{
	return [points count];
}
- (CPTLayer *) dataLabelForPlot:		(CPTPlot *) 	plot
                    recordIndex:		(NSUInteger) 	index{
    NSNumber* num=[[points objectAtIndex:index] valueForKey:@"y"];
    CPTTextLayer *label	= [[CPTTextLayer alloc] initWithText:[NSString stringWithFormat:@"%d", [num intValue]]];
	CPTMutableTextStyle *textStyle = [label.textStyle mutableCopy];
    
	textStyle.color = [CPTColor lightGrayColor];
	label.textStyle = textStyle;
	[textStyle release];
	return [label autorelease];
}
-(NSNumber *)numberForPlot:(CPTPlot *)plot field:(NSUInteger)fieldEnum recordIndex:(NSUInteger)index
{
	NSString *key = (fieldEnum == CPTScatterPlotFieldX ? @"x" : @"y");
	NSNumber *num = [[points objectAtIndex:index] valueForKey:key];
    
	return num;
}
- (void)viewDidUnload
{
    [self setHostingView:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (void)dealloc {
    [hostingView release];
    [super dealloc];
}

@end
