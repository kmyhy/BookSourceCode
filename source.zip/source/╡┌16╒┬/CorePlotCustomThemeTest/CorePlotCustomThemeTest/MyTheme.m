//
//  MyTheme.m
//  CorePlotCustomThemeTest
//
//  Created by chen neng on 12-7-28.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import "MyTheme.h"

@implementation MyTheme
-(void)applyThemeToBackground:(CPTXYGraph *)graph 
{
	CPTColor *endColor = [CPTColor colorWithGenericGray:0.2f];//1
	CPTGradient *graphGradient = [CPTGradient gradientWithBeginningColor:endColor endingColor:endColor];// 2
	graphGradient = [graphGradient addColorStop:[CPTColor colorWithGenericGray:0.3f] atPosition:0.3f];// 3
	graphGradient = [graphGradient addColorStop:[CPTColor colorWithGenericGray:0.5f] atPosition:0.5f];// 4
	graphGradient = [graphGradient addColorStop:[CPTColor colorWithGenericGray:0.3f] atPosition:0.6f];// 5
	graphGradient.angle = 90.0f;// 6
	graph.fill = [CPTFill fillWithGradient:graphGradient];// 7
}
-(void)applyThemeToAxisSet:(CPTXYAxisSet *)axisSet {
    CPTMutableLineStyle *majorGridLineStyle = [CPTMutableLineStyle lineStyle];// 1
    majorGridLineStyle.lineWidth = 1.0f;// 2
    majorGridLineStyle.lineColor = [CPTColor lightGrayColor];// 3
	
	CPTXYAxis *axis=axisSet.yAxis;// 4
	axis.tickDirection = CPTSignNegative;// 5
    axis.majorGridLineStyle = majorGridLineStyle ;// 6
    //axis.labelingPolicy = CPAxisLabelingPolicyNone ;
}
-(void)applyThemeToPlotArea:(CPTPlotAreaFrame *)plotAreaFrame 
{
    CPTGradient *gradient = [CPTGradient gradientWithBeginningColor:[CPTColor colorWithGenericGray:0.2f] endingColor:[CPTColor colorWithGenericGray:0.7f]];// 1
    gradient.angle = 45.0f;// 2
	plotAreaFrame.fill = [CPTFill fillWithGradient:gradient]; // 3
}


@end
