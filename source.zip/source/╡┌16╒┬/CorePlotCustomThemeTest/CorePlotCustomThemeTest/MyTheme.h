//
//  MyTheme.h
//  CorePlotCustomThemeTest
//
//  Created by chen neng on 12-7-28.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CorePlot-CocoaTouch.h"


@interface MyTheme : CPTTheme

@end
