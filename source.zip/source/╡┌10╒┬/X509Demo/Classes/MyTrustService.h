//
//  MyTrustService.h
//  test
//
//  Created by steven yang on 11-5-13.
//  Copyright 2011 kmyhy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Security/Security.h>
typedef enum
{
	ValuateResultINVALID = 0,	// 评估结果无效，表明评估出错或未经过评估
	ValuateResultFAILED,		// 证书签名无效
	ValuateResultEXPIRED,		// 证书过期
	ValuateResultOK				// 证书有效
} ValuateResult;

@interface MyTrustService : NSObject {
	NSString *file;	
	NSDate* efficientDate;
}
-(id)initWithFilename:(NSString*)filename EfficientDate:(NSDate*)date;
-(ValuateResult)trustValuate:(NSDate*)date;
-(ValuateResult)valuate:(SecCertificateRef)cert Trust:(SecTrustRef)trust Date:(NSDate*)date;
@end
