//
//  X509DemoAppDelegate.h
//  X509Demo
//
//  Created by chen neng on 11-10-6.
//  Copyright 2011 ydtf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "MyTrustService.h"

@interface X509DemoAppDelegate : NSObject <UIApplicationDelegate> {
    
    UIWindow *window;
	UITextField* tfDate;
    
@private
    NSManagedObjectContext *managedObjectContext_;
    NSManagedObjectModel *managedObjectModel_;
    NSPersistentStoreCoordinator *persistentStoreCoordinator_;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic,retain)IBOutlet UITextField* tfDate;
@property (nonatomic, retain, readonly) NSManagedObjectContext *managedObjectContext;
@property (nonatomic, retain, readonly) NSManagedObjectModel *managedObjectModel;
@property (nonatomic, retain, readonly) NSPersistentStoreCoordinator *persistentStoreCoordinator;

- (NSURL *)applicationDocumentsDirectory;
- (void)saveContext;
-(IBAction)valuate;
@end

