//
//  MyTrustService.m
//  test
//
//  Created by steven yang on 11-5-13.
//  Copyright 2011 kmyhy. All rights reserved.
//

#import "MyTrustService.h"


@implementation MyTrustService
-(id)initWithFilename:(NSString*)filename EfficientDate:(NSDate*)date{
	if (self=[super init]) {
		file=filename;
		// 设置有效日期，注意，第2个参数是一个有效的证书日期，只要这个日期对证书而言是有效的就行
		efficientDate=[date retain];		
	}
	return self;
}
-(ValuateResult)trustValuate:(NSDate*)date{
	ValuateResult ret;
	OSStatus            err;
    NSData *            certData;
    SecCertificateRef   cert;
    SecPolicyRef        policy;
    SecTrustRef         trust;
 	
    assert(file != nil);
    assert(date != nil);
	
	// 从文件获得 DER 数据
    certData = [NSData dataWithContentsOfFile:file];
    assert(certData != nil);
	
	// 从 NSData 获得 Certificate 对象
    cert = SecCertificateCreateWithData(NULL, (CFDataRef) certData);
    assert(cert != NULL);
	
	// 获得 x509 policy
    policy = SecPolicyCreateBasicX509();
    assert(policy != NULL);
	
	// 获得 Trust 对象
    err = SecTrustCreateWithCertificates(cert, policy, &trust);
    assert(err == noErr);
	
	// 由于是自签名证书，需要将锚证书设置为要验证的证书自己。注意，这样将使所有除了参数指定的锚证书之外的所有锚证书无效
    err = SecTrustSetAnchorCertificates(trust, (CFArrayRef) [NSArray arrayWithObject:(id) cert]);
    assert(err == noErr);
	
	// 调用 valuate 方法进行评估
	ret=[self valuate:cert Trust:trust Date:date];
	
	// 评估结束，把SecTrustSetAnchorCertificates指定的锚证书失效，于是所有锚证书又可被信任了
   	err=SecTrustSetAnchorCertificatesOnly(trust,NO);
    CFRelease(trust);
    CFRelease(policy);
    CFRelease(cert);
	return ret;
}
-(ValuateResult)valuate:(SecCertificateRef)cert Trust:(SecTrustRef)trust Date:(NSDate*)date{
	ValuateResult ret;
	OSStatus            err;
    SecTrustResultType  result;
	static const char * kTrustNames[8] = {
		"Invalid",
		"Proceed",
		"Confirm",
		"Deny",
		"Unspecified",
		"RecoverableTrustFailure",
		"FatalTrustFailure",
		"OtherError"
	};
	
    err = SecTrustSetVerifyDate(trust, (CFDateRef) date);
    assert(err == noErr);
	
	CFAbsoluteTime trustTime;
	trustTime = SecTrustGetVerifyTime(trust);
	
    err = SecTrustEvaluate(trust, &result);
    assert(err == noErr);
	
    if (result < (sizeof(kTrustNames) / sizeof(*kTrustNames))) {// if(result < 8)
        if (result==5) {// if result=RecoverableTrustFailure
			// 设了个有效的日期，进行再次评估
			NSLog(@"%@",efficientDate);
			err=SecTrustSetVerifyDate(trust, (CFDateRef)efficientDate);
			assert(err==noErr);
			err=SecTrustEvaluate(trust, &result);
			assert(err == noErr);
			if (result==4) {// if result=Unspecified,
				// 返回证书已过期，这里我们假设把证书尚未生效的情况也算作过期
				ret= ValuateResultEXPIRED;
			}
		}else if (result==4) {// 如果第1次就通过评估，证书有效
			ret=ValuateResultOK; 
		}else {
			ret=ValuateResultFAILED;//证书 无效
		}

		
    } else {
//        NSLog(@"result = unknown (%zu)", (size_t) result);
    }
	return ret;
}
-(void)dealloc{
	[efficientDate release];
	[super dealloc];
}
@end
