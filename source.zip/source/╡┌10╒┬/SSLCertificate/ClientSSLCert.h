//
//  ClientSSLCert.h
//  DLT
//
//  Created by chen neng on 11-9-19.
//  Copyright 2011 ydtf. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FileDownload.h"
#import "Contants.h"
#define CertificatePass @"ydtf@95598"
#define CertificateFile @"tomcatClient.p12"
// 获取用户document目录
#define UserDocFolder [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]
#define CertificatePath [UserDocFolder stringByAppendingPathComponent: CertificateFile]

OSStatus extractIdentityAndTrust(NSData* inPKCS12Data,        // 5
                                 SecIdentityRef *outIdentity,
                                 SecTrustRef *outTrust);

@interface ClientSSLCert : NSObject {
	FileDownload* fdl;
}
-(bool)isCertFileExists;
-(bool)deleteCertFile;
-(bool)download:(bool)override;
-(OSStatus)valuate;
-(SecIdentityRef)identity;
@end
