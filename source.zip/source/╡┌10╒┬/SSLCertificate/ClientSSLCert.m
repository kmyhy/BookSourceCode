//
//  ClientSSLCert.m
//  DLT
//
//  Created by chen neng on 11-9-19.
//  Copyright 2011 ydtf. All rights reserved.
//

#import "ClientSSLCert.h"


@implementation ClientSSLCert
-(id)init{
	if (self=[super init]) {
		fdl=[[FileDownload alloc]initWithFilename:CertificateFile 
											  URL:CLIENTSSLCERTIFICATE_URL];
//		NSLog(@"filename:%@,url:%@",CertificateFile,CLIENTSSLCERTIFICATE_URL);
	}
	return self;
}
// 判断证书是否存在
-(bool)isCertFileExists{
	return [fdl fileExists:CertificateFile];
}
-(bool)deleteCertFile{
	return [fdl deleteFile:CertificateFile];
}
-(bool)download:(bool)override{
	return [fdl download:override];
}
-(OSStatus)valuate{
	NSData *PKCS12Data = [[NSData alloc] initWithContentsOfFile:CertificatePath];
    CFDataRef inPKCS12Data = (CFDataRef)PKCS12Data;             // 1
	
	OSStatus status = noErr;
    SecIdentityRef myIdentity;
    SecTrustRef myTrust;
    status = extractIdentityAndTrust(
                                     (NSData*)inPKCS12Data,
                                     &myIdentity,
                                     &myTrust);                 // 2
	
	SecTrustResultType trustResult;
	
    if(status==0){
		status = SecTrustEvaluate(myTrust, &trustResult);
	}
	[PKCS12Data release];
    return status;
}
-(SecIdentityRef)identity{
	SecIdentityRef identity=NULL;
	SecTrustRef trust = NULL;
	NSData *PKCS12Data = [NSData dataWithContentsOfFile:CertificatePath];	
	extractIdentityAndTrust(PKCS12Data,&identity,&trust);
	return identity;
}
-(void)dealloc{
	[fdl release];
	[super dealloc];
}
@end
OSStatus extractIdentityAndTrust(NSData* inPKCS12Data,        // 5
                                 SecIdentityRef *outIdentity,
                                 SecTrustRef *outTrust)
{
    OSStatus securityError = errSecSuccess;
    
    
    CFStringRef password = (CFStringRef)CertificatePass;//CFSTR("ydtf@95598");
    const void *keys[] =   { kSecImportExportPassphrase };
    const void *values[] = { password };
    CFDictionaryRef optionsDictionary = CFDictionaryCreate(
                                                           NULL, keys,
                                                           values, 1,
                                                           NULL, NULL);  // 6
    
    
    CFArrayRef items = CFArrayCreate(NULL, 0, 0, NULL);
    securityError = SecPKCS12Import((CFDataRef)inPKCS12Data,
                                    optionsDictionary,
                                    &items);                    // 7
    
    
    //
    if (securityError == 0) {                                   // 8
        CFDictionaryRef myIdentityAndTrust = (CFDictionaryRef)CFArrayGetValueAtIndex (items, 0);
        const void *tempIdentity = NULL;
        tempIdentity = CFDictionaryGetValue (myIdentityAndTrust,
                                             kSecImportItemIdentity);
        *outIdentity = (SecIdentityRef)tempIdentity;
        const void *tempTrust = NULL;
        tempTrust = CFDictionaryGetValue (myIdentityAndTrust, kSecImportItemTrust);
        *outTrust = (SecTrustRef)tempTrust;
    }
    
    if (optionsDictionary)
        CFRelease(optionsDictionary);                           // 9
    
    return securityError;
}
