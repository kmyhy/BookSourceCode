//
//  DES.h
//  DesEncryptTest
//
//  Created by chen neng on 12-7-16.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Security/Security.h>
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCryptor.h>


//#define secret_key @"B6477B2D-5B0B-4324-94B7-572AC276B88D"
@interface DES : NSObject

// 采用DES加密或者解密数据
+(NSData *)desData:(NSData *)data key:(NSString *)key CCOperation:(CCOperation)op;
+(NSString *)encrypt : (NSString *)explicitText key :(NSString *)key;
+(NSString *)decrypt: (NSString *)cipherText key :(NSString *)key;
+(NSString *)dataToHex:(NSData *)data;
+(NSData*)hexToData:(NSString*)hex;
@end