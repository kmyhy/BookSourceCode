//
//  NSURL+Parameters.m
//  DesEncryptTest
//
//  Created by kmyhy on 12-9-28.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import "NSURL+Parameters.h"


@implementation NSURL (QSParameters)


- (NSDictionary *)parameters {
    if (![self query]) return nil;
    NSScanner *scanner = [NSScanner scannerWithString:[self query]];
    if (!scanner) return nil;
    NSMutableDictionary* dictionary=[NSMutableDictionary dictionary];
    NSString* key,*value;
    while (![scanner isAtEnd]) {
        if (![scanner scanUpToString:@"=" intoString:&key]) {
            key=nil;
        }
        [scanner scanString:@"=" intoString:nil];
        if (![scanner scanUpToString:@"&" intoString:&value]) {
            value=nil;
        }
        [scanner scanString:@"&" intoString:nil];
        key = [key stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        value = [value stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        if (key && value) {// do not allowed to add a "nil" valued object to an NSMutableDictionary
            [dictionary setObject:value forKey:key];
        }

    }
    return dictionary;
}
-(NSString*)getParameterByName:(NSString*)parameterName{
    if (!parameterName && ![self parameters]) return nil;
    return [[self parameters]objectForKey:parameterName];
}

@end

