//
//  ViewController.h
//  DesEncryptTest
//
//  Created by chen neng on 12-7-16.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController{
    NSString* text;
}
@property (retain, nonatomic) IBOutlet UITextView *tvExplicit;


@property (retain, nonatomic) IBOutlet UIButton *button;

- (IBAction)EncryptOrDecrypt:(id)sender;
@end
