//
//  DES.m
//  DesEncryptTest
//
//  Created by chen neng on 12-7-16.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import "DES.h"
static char cIv[8]={1,0,6,2,9,5,5,9};
@implementation DES
//data是需要加密或解密的数据，keyString 是密码（一般是8位），op表示加密/解密
+ (NSData *)desData:(NSData *)data key:(NSString *)key CCOperation:(CCOperation)op
{
    // buffer大小应该由下面公式计算。如果bufferSzie太小，无法正确解密
    NSUInteger bufferSize= ([data length] + kCCKeySizeDES) & ~(kCCKeySizeDES -1);
    char buffer[bufferSize] ;
    memset(buffer, 0, sizeof(buffer));
    size_t bufferNumBytes;
    CCCryptorStatus cryptStatus = CCCrypt(op, 
                                          kCCAlgorithmDES, 
                                          kCCOptionPKCS7Padding,
                                          [key UTF8String], 
                                          kCCKeySizeDES,
                                          cIv, 
                                          [data bytes], 
                                          [data length],
                                          buffer, 
                                          bufferSize,
                                          &bufferNumBytes);
//    NSLog(@"crypt status:%d",cryptStatus);
    if(cryptStatus == kCCSuccess)
    {
        return [NSData dataWithBytes:buffer length:bufferNumBytes];
    }
    return nil;
}

+(NSString *)encrypt : (NSString *)explicitText key :(NSString *)key
{
    if (explicitText == nil || key == nil || explicitText.length == 0 || key.length == 0) {
        return nil;
    }
    NSData* data= [DES desData: [explicitText dataUsingEncoding: NSUTF8StringEncoding]
                               key: key
                CCOperation: kCCEncrypt];
    
//    NSLog(@"data:%@",data);
    
    NSString* ret= [DES dataToHex:data];
//    NSLog(@"encrypt:%@",ret);
    return ret;
}
+(NSString *)decrypt: (NSString *)cipherText key :(NSString *)key
{
    
    if (cipherText == nil || key == nil || cipherText.length==0 || key.length == 0) {
        return @"";
    }
    NSData* cipherData=[DES hexToData:cipherText];
//    NSLog(@"cipher data:%@",cipherData);
    NSData *decryptData = [DES desData: cipherData
                                   key: key
                               CCOperation: kCCDecrypt];
    if (decryptData == nil) {
//        NSLog(@"decrypt:%@",@"");
        return @"";
    }
    NSString* ret= [[[NSString alloc] initWithData: decryptData
                                  encoding: NSUTF8StringEncoding] autorelease];
//    NSLog(@"decrypt:%@",ret);
    return ret;
}
+(NSString *)dataToHex:(NSData *)data{
    
    NSMutableString* ret=[[NSMutableString alloc]init];
    Byte* bytes=(Byte*)[data bytes];
    for (int i=0;i<[data length];i++ ) {
        NSString* s=[NSString stringWithFormat:@"%X",bytes[i] & 0xff];
        if (s.length==1) {
            [ret appendFormat:@"0%@",s];
        }else{
            [ret appendFormat:s];
        }
    }
    return ret;
}
+(NSData*)hexToData:(NSString*)hex{
    NSMutableData* ret=[[NSMutableData alloc]init];
    for (int i=0; i<hex.length/2; i++) {
        NSString* byteStr=[NSString stringWithFormat:@"%c%c",[hex characterAtIndex:i*2],[hex characterAtIndex:i*2+1]];
        unsigned i=0;
        NSScanner* scanner = [NSScanner scannerWithString:byteStr];
        [scanner scanHexInt:&i];
        [ret appendBytes:&i length:1];
//        NSLog(@"byte str:%@,int:%X",byteStr,i);
    }
    return ret;
}
@end
