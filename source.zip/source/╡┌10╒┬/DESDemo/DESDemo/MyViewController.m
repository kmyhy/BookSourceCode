//
//  MyViewController.m
//  DESDemo
//
//  Created by chen neng on 12-5-16.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import "MyViewController.h"
#import "Decrypt.h"
#define FOLDER_DOCUMENT \
[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]

void showMessage(NSString* title,NSString* msg){
	UIAlertView* alert=[[UIAlertView alloc]initWithTitle:title
												 message:msg delegate:nil
									   cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[alert show];
	[alert release];
}
@implementation MyViewController
@synthesize tfPass;
@synthesize btSavePass;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSString* filename=[FOLDER_DOCUMENT stringByAppendingPathComponent:@"secrecy.txt"];
    if ([[NSFileManager defaultManager]fileExistsAtPath:filename]) {
        NSData* data=[NSData dataWithContentsOfFile:filename];
        if (data) {
            NSString* pass=[Decrypt decryptStringFromData:data key:secret_key];
            tfPass.text=pass;
            btSavePass.tag=1;
            [btSavePass setImage:[UIImage imageNamed:@"checked.png"] forState:UIControlStateNormal];
        }else{
            tfPass.text=nil;
            btSavePass.tag=0;
            [btSavePass setImage:[UIImage imageNamed:@"unchecked.png"] forState:UIControlStateNormal];
            
        }
    }
}

- (void)viewDidUnload
{
    [self setBtSavePass:nil];
    [self setTfPass:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [btSavePass release];
    [tfPass release];
    [super dealloc];
}
-(void)savePass:(BOOL)b{
    NSString* filename=[FOLDER_DOCUMENT stringByAppendingPathComponent:@"secrecy.txt"];
    btSavePass.tag=b;
    if (b) {
        if (tfPass.text && tfPass.text.length>0) {
            [btSavePass setImage:[UIImage imageNamed:@"checked.png"] forState:UIControlStateNormal];
            NSData* data=[Decrypt encryptDataFromString:tfPass.text key:secret_key];
      
            if(data){
                [data writeToFile:filename atomically:YES];
            }
        }else{
            showMessage(@"", @"不能保存空密码");
            [self savePass:NO];
        }
    }else{
        [btSavePass setImage:[UIImage imageNamed:@"unchecked.png"] forState:UIControlStateNormal];
//        [[NSData data] writeToFile:filename atomically:YES];
    }
}
- (IBAction)savePassAction:(id)sender {
    BOOL b=(btSavePass.tag==0);
    [self savePass:b];
}
#pragma mark Text Field Delegate Method
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField==tfPass) {// 密码被改，要求重新选择“记住密码”
        [self savePass:NO];
    }
}

@end
