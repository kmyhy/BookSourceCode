//
//  Decrypt.m
//  YhyLib
//
//  Created by chen neng on 12-2-17.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import "Decrypt.h"

@implementation Decrypt
//data是需要加密或解密的数据，keyString 是密码（一般是8位），op表示加密/解密
+ (NSData *)desData:(NSData *)data key:(NSString *)key CCOperation:(CCOperation)op
{
    char buffer[1024] ;
    memset(buffer, 0, sizeof(buffer));
    size_t bufferNumBytes;
    CCCryptorStatus cryptStatus = CCCrypt(op, 
                                          kCCAlgorithmDES, 
                                          kCCOptionPKCS7Padding | kCCOptionECBMode,
                                          [key UTF8String], 
                                          kCCKeySizeDES,
                                          NULL, 
                                          [data bytes], 
                                          [data length],
                                          buffer, 
                                          1024,
                                          &bufferNumBytes);
    if(cryptStatus == kCCSuccess)
    {
        return [NSData dataWithBytes:buffer length:bufferNumBytes];
    }
    return nil;
}

+(NSData *)encryptDataFromString : (NSString *)string key :(NSString *)key
{
    if (string == nil || key == nil || string.length == 0 || key.length == 0) {
        return nil;
    }
    return [Decrypt desData: [string dataUsingEncoding: NSUTF8StringEncoding]
                              key: key
                      CCOperation: kCCEncrypt];
}
+(NSString *)decryptStringFromData : (NSData *)data key :(NSString *)key
{
    if (data == nil || key == nil || key.length == 0) {
        return @"";
    }
    NSData *decryptData = [Decrypt desData: data
                                             key: key
                                     CCOperation: kCCDecrypt];
    if (decryptData == nil) {
        return @"";
    }
    return [[[NSString alloc] initWithData: decryptData
                                  encoding: NSUTF8StringEncoding] autorelease];
}
@end
