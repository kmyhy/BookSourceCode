//
//  MyViewController.h
//  DESDemo
//
//  Created by chen neng on 12-5-16.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyViewController : UIViewController<UITextFieldDelegate>

@property (retain, nonatomic) IBOutlet UITextField *tfPass;
@property (retain, nonatomic) IBOutlet UIButton *btSavePass;
- (IBAction)savePassAction:(id)sender;
@end
void showMessage(NSString* title,NSString* msg);