//
//  Decrypt.h
//  YhyLib
//
//  Created by chen neng on 12-2-17.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Security/Security.h>
#import <CommonCrypto/CommonDigest.h>
#import <CommonCrypto/CommonCryptor.h>

#define secret_key @"12345678"

@interface Decrypt : NSObject
// 采用DES加密或者解密数据
+(NSData *)desData:(NSData *)data key:(NSString *)key CCOperation:(CCOperation)op;
+(NSData *)encryptDataFromString : (NSString *)string key :(NSString *)key;
+(NSString *)decryptStringFromData : (NSData *)data key :(NSString *)key;
@end
