//
//  ViewController.h
//  LocalizableDemo
//
//  Created by chen neng on 12-6-12.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (retain, nonatomic) IBOutlet UILabel *textLabel;

@end
