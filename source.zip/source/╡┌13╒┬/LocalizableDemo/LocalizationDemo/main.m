//
//  main.m
//  LocalizationDemo
//
//  Created by chen neng on 11-10-8.
//  Copyright 2011 ydtf. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
