//
//  HelloViewController.h
//  LocalizationDemo
//
//  Created by chen neng on 11-10-8.
//  Copyright 2011 ydtf. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface HelloViewController : UIViewController {
	UILabel *label;
	UIImageView *imageView;
}
@property (retain,nonatomic)IBOutlet UILabel* label;
@property (retain,nonatomic)IBOutlet UIImageView* imageView;
@end
