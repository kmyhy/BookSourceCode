//
//  LocalizationDemoAppDelegate.h
//  LocalizationDemo
//
//  Created by chen neng on 11-10-8.
//  Copyright 2011 ydtf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HelloViewController.h"

@interface LocalizationDemoAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

