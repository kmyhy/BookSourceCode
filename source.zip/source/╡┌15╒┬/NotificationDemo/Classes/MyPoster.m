//
//  MyPoster.m
//  NotificationDemo
//
//  Created by chen neng on 11-10-10.
//  Copyright 2011 ydtf. All rights reserved.
//

#import "MyPoster.h"


@implementation MyPoster
@synthesize text;
-(void)changeText:(NSDictionary*)userInfo{
	
    [[NSNotificationCenter defaultCenter] postNotificationName:noti_key
                                                        object:self
                                                      userInfo:userInfo];
}
-(void)dealloc{
//	[text release];
	[super dealloc];
}
@end
