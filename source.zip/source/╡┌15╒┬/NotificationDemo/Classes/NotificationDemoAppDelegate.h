//
//  NotificationDemoAppDelegate.h
//  NotificationDemo
//
//  Created by chen neng on 11-10-10.
//  Copyright 2011 ydtf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyPoster.h"
#import "MyObserver.h"
@interface NotificationDemoAppDelegate : NSObject <UIApplicationDelegate,UITextViewDelegate> {
    UIWindow *window;
    MyObserver* observer;
	MyPoster* poster;
    NSNotificationCenter* center;
}
@property (retain, nonatomic) IBOutlet UIButton *button;

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (retain, nonatomic) IBOutlet UITextView *textView;

-(IBAction)regOrUnregObserver;
- (IBAction)freeKeyboard:(id)sender;
@end

