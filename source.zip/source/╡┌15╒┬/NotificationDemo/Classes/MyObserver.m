//
//  MyObserver.m
//  NotificationDemo
//
//  Created by chen neng on 11-10-10.
//  Copyright 2011 ydtf. All rights reserved.
//

#import "MyObserver.h"


@implementation MyObserver
-(void)handleNotification:(NSNotification*)notification{
	NSLog(@"%@:\n%@",notification.name,notification.userInfo);
}
@end
