//
//  MyObserver.h
//  NotificationDemo
//
//  Created by chen neng on 11-10-10.
//  Copyright 2011 ydtf. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MyPoster.h"

@interface MyObserver : NSObject {

}
-(void)handleNotification:(NSNotification*)notification;
@end
