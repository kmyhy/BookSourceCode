//
//  MyPoster.h
//  NotificationDemo
//
//  Created by chen neng on 11-10-10.
//  Copyright 2011 ydtf. All rights reserved.
//

#import <Foundation/Foundation.h>
#define noti_key @"MyPosterChangedNotification"

@interface MyPoster : NSObject {
	NSString* text;
}
@property (retain,nonatomic)NSString* text;
-(void)changeText:(NSDictionary*)userInfo;
@end
