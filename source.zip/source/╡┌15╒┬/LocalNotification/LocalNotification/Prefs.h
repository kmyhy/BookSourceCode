//
//  Prefs.h
//  YunnanDLT
//
//  Created by chen neng on 12-5-11.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Prefs : NSObject
+(NSUserDefaults*)defaults;
+(NSMutableArray*)array;
+(void)setArray:(NSArray*)array;
+(int)badgeNumber;
+(void)setBadgeNumber:(int)number;

@end
