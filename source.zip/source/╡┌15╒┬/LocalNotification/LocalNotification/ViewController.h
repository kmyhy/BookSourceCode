//
//  ViewController.h
//  LocalNotificationDemo
//
//  Created by chen neng on 12-7-19.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
@property (retain, nonatomic) IBOutlet UISwitch *sw;
@property (retain, nonatomic) IBOutlet UITableView *table;
@property (nonatomic,readonly,getter = showedNotifications)int showed_noti;
@property (retain,nonatomic)NSMutableArray* mArray;
@property (nonatomic)BOOL switchON;
- (IBAction)onOrOff:(id)sender;
-(void)showNotification:(int)number;
-(void)restoreDefault;
@end
