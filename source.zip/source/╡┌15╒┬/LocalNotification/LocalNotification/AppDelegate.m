//
//  AppDelegate.m
//  LocalNotificationDemo
//
//  Created by chen neng on 12-7-19.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import "AppDelegate.h"
#import "Prefs.h"

#import "ViewController.h"

@implementation AppDelegate

@synthesize window = _window;
@synthesize viewController = _viewController;

- (void)dealloc
{
    [_window release];
    [_viewController release];
    [super dealloc];
}
// This will be done when app is launching
static int taps=0;
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    taps++;
    NSLog(@"tap app icon %d times.",taps);
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    // Override point for customization after application launch.
    self.viewController = [[[ViewController alloc] initWithNibName:@"ViewController" bundle:nil] autorelease];
    self.window.rootViewController = self.viewController;
    Class cls = NSClassFromString(@"UILocalNotification");
    if (cls) {
        UILocalNotification *notification = [launchOptions objectForKey:
                                             UIApplicationLaunchOptionsLocalNotificationKey];
        
        if (notification && notification.userInfo) {
//            --application.applicationIconBadgeNumber;
            self.viewController.switchON=YES;
            
        }
    }
    

    [self.window makeKeyAndVisible];

    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}
-(void)refreshBadges:(UIApplication*)application{
    application.applicationIconBadgeNumber=self.viewController.showed_noti;
}
- (void)applicationDidEnterBackground:(UIApplication *)application
{
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
     */
    // 设置超时handler，超时时系统会调用这个块
    backgroundTask = [application beginBackgroundTaskWithExpirationHandler: ^{  
        // 提交一个块到目标队列，以便异步执行
        dispatch_async(dispatch_get_main_queue(), ^{  
            if (backgroundTask != UIBackgroundTaskInvalid)  
            {  
                [application endBackgroundTask:backgroundTask];  
                backgroundTask = UIBackgroundTaskInvalid;  
            } 
        });  
    }];  
    //    
    // 开始运行后台任务  
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{  
        //        [[HTTPServer sharedHTTPServer]start];
        dispatch_source_t timer;
        timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0));  
        dispatch_source_set_timer(timer, DISPATCH_TIME_NOW, 3ull * NSEC_PER_SEC, 0);  
        dispatch_source_set_event_handler(timer, ^{ 
            [self refreshBadges:application];  
        });  
        dispatch_resume(timer);     
    });  
      
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    /*
     Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
     */
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    /*
     Called when the application is about to terminate.
     Save data if appropriate.
     See also applicationDidEnterBackground:.
     */
    [Prefs setBadgeNumber:self.viewController.showed_noti];
    [Prefs setArray:self.viewController.mArray];
}
// This will be done when app is in background and foreground

- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification{
    if(notification.userInfo){
        int number=((NSNumber*)[notification.userInfo objectForKey:@"number"]).intValue;
        NSLog(@"notification number:%d", number);
        [self.viewController showNotification:number];
    }
}
@end
