//
//  ViewController.m
//  LocalNotificationDemo
//
//  Created by chen neng on 12-7-19.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import "ViewController.h"
#import "Prefs.h"

@implementation ViewController
@synthesize sw;
@synthesize table;
@synthesize mArray;
@synthesize switchON;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    if (switchON) {
        [sw setOn:YES];
        [self onOrOff:sw];
    }
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];

}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}
#pragma mark - getter
-(int)showedNotifications{
    int result=0;
    for (NSDictionary* each in mArray) {
        if ([@"NO" isEqualToString:[each objectForKey:@"didRead"]]) {
            result++;
        }
    }
    result=result-[[UIApplication sharedApplication]scheduledLocalNotifications].count;
    return result;
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (void)dealloc {
    [mArray release];
    [sw release];
    [table release];
    [super dealloc];
}

-(void)scheduleNotification:(int)index{
    assert([mArray objectAtIndex:index]);
    NSMutableDictionary* dictionary=[mArray objectAtIndex:index];
    if ([@"YES" isEqualToString:[dictionary objectForKey:@"didRead"]]) {
        return;
    }
    
    // 构造本地通知对象
    UILocalNotification *notification=[[UILocalNotification alloc] init];   
    // 设置通知对象的属性
    notification.timeZone=[NSTimeZone defaultTimeZone];//时区
    notification.repeatInterval=0;//重复周期,0-不重复
    NSNumber* number=[dictionary objectForKey:@"number"];
    notification.applicationIconBadgeNumber = number.intValue;//徽章数
    notification.alertBody=@"收到一条提醒消息。";//告警消息文本
    [notification setSoundName:UILocalNotificationDefaultSoundName];//声音
    NSNumber* time=[dictionary objectForKey:@"time"];
    notification.fireDate=[NSDate dateWithTimeIntervalSinceNow:time.intValue];
    [dictionary setObject:notification.fireDate forKey:@"fire_date"];
    [notification setUserInfo:dictionary];
    
    // 调度本地通知
    [[UIApplication sharedApplication]scheduleLocalNotification:notification];
    [notification release];
}
-(void)restoreDefault{
    mArray=[[NSMutableArray alloc]init];
    NSArray* arr=[Prefs array];
    int number=[Prefs badgeNumber];
    if (number!=0) {
        [UIApplication sharedApplication].applicationIconBadgeNumber=number;
    }
    if (arr==nil || arr.count==0) {
        for (int i=1; i<5; i++) {
            NSMutableDictionary* d=[NSMutableDictionary dictionaryWithObjectsAndKeys:
                                    [NSNumber numberWithInt:i],@"number",
                                    [NSNumber numberWithInt:10*i],@"time",
                                    @"NO",@"didRead",
                                    @"It's time to do something.",@"info",nil];
            [mArray addObject:d];
            
        }
    }else{
        for (NSDictionary* each in arr) {
            [mArray addObject:[each mutableCopy]];
        }
    }
}
-(IBAction)onOrOff:(id)sender{
	if(sw.on){
        [self restoreDefault];
        [[UIApplication sharedApplication]cancelAllLocalNotifications];
         for(NSDictionary* each in mArray){
             int index=((NSNumber*)[each objectForKey:@"number"]).intValue;
            [self scheduleNotification:index-1];
        }
        [table reloadData];

    }else {
		// 取消所有通知
        [mArray removeAllObjects];
        [table reloadData];
		[[UIApplication sharedApplication] cancelAllLocalNotifications];
	}
}
#pragma makr - table view datasource and delegate
-(float)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 45;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return mArray.count;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier=@"identifier";
    UITableViewCell* cell=[tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell==nil) {
        cell=[[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleValue1
                                    reuseIdentifier:identifier]autorelease];
    }
    NSDictionary* dic=(NSDictionary*)[mArray objectAtIndex:indexPath.row];
    NSDate* date=(NSDate*)[dic objectForKey:@"fire_date"];
    NSDateFormatter* df=[[NSDateFormatter alloc]init];
    [df setDateFormat:@"HH:mm:ss"];
    cell.detailTextLabel.text=[df stringFromDate:date];
    NSNumber* number=[dic objectForKey:@"number"];
    cell.textLabel.text=number.stringValue;
    
    if ([@"NO" isEqualToString:[dic objectForKey:@"didRead"]]) {
        cell.accessoryType=UITableViewCellAccessoryNone;
    }else{
        cell.accessoryType=UITableViewCellAccessoryCheckmark;
    }
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self showNotification:indexPath.row+1];

    for (UILocalNotification* each in 
         [UIApplication sharedApplication].scheduledLocalNotifications) {
        int number=((NSNumber*)[each.userInfo objectForKey:@"number"]).intValue; 
        if (number-1==indexPath.row) {
            [[UIApplication sharedApplication]cancelLocalNotification:each];
            break;
        }
    }
}
-(void)showNotification:(int)number{
    
    NSMutableDictionary* dic=(NSMutableDictionary*)[mArray objectAtIndex:number-1];
    NSString* info=(NSString*)[dic objectForKey:@"info"];
    UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:@""
                                                     message:info
                                                    delegate:nil cancelButtonTitle:@"好" otherButtonTitles:nil];
    [alertView show];
    if ([@"NO" isEqualToString:[dic objectForKey:@"didRead"]]) {
        [dic setObject:@"YES" forKey:@"didRead"];
        [table reloadData];
    }
    
}
@end







