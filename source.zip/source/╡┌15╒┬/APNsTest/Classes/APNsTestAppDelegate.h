//
//  APNsTestAppDelegate.h
//  APNsTest
//
//  Created by chen neng on 11-8-31.
//  Copyright ydtf 2011. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface APNsTestAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

