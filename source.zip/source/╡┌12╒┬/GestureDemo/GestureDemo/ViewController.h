//
//  ViewController.h
//  GestureDemo
//
//  Created by chen neng on 12-5-31.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController{
    CGRect originFrame;
}
@property (retain, nonatomic) IBOutlet UIImageView *imageView;
@property (nonatomic)float scale;
@end
