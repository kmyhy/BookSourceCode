//
//  ViewController.m
//  GestureDemo
//
//  Created by chen neng on 12-5-31.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController
@synthesize imageView;
@synthesize scale;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	UIPinchGestureRecognizer *pinchRecognizer =[[UIPinchGestureRecognizer alloc]
                      initWithTarget:self
                      action:@selector(pinchDetected:)]; 
    [self.view addGestureRecognizer:pinchRecognizer]; 
    [pinchRecognizer release]; 
    
    UIPanGestureRecognizer* panRecognizer=[[UIPanGestureRecognizer alloc]
                                           initWithTarget:self
                                           action:@selector(panDetected:)];
    [self.view addGestureRecognizer:panRecognizer];
    [panRecognizer release];
    
    UITapGestureRecognizer* tapRecognizer=[[UITapGestureRecognizer alloc]
                                           initWithTarget:self
                                           action:@selector(tapDetected:)];
    tapRecognizer.numberOfTapsRequired=2;
    [self.view addGestureRecognizer:tapRecognizer];
    [tapRecognizer release];
    
    originFrame=imageView.frame;
}

- (void)viewDidUnload
{
    [self setImageView:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (void)dealloc {
    [imageView release];
    [super dealloc];
}
-(void)pinchDetected:(UIPinchGestureRecognizer *)sender{
    scale =  [sender scale];
    CGSize size=imageView.frame.size;
    imageView.frame=CGRectMake(0, 0, size.width*scale, size.height*scale);
    [imageView setNeedsLayout];
//    imageView.transform = CGAffineTransformMakeScale(scaleFactor, scaleFactor);
}
-(void)panDetected:(UIPanGestureRecognizer*)sender{
    CGPoint center=imageView.center;
     
    CGPoint trans = [sender translationInView:imageView];
    [imageView setCenter:CGPointMake(center.x+trans.x,center.y+trans.y)];
    // 由于平移是一个连续手势，它会不断地累加translation的值，因此我们每次移动完ImageView后把translation清零
    [sender setTranslation:CGPointZero inView:imageView];
//    imageView.transform = CGAffineTransformMakeTranslation(trans.x, trans.y);
}
-(void)tapDetected:(UITapGestureRecognizer*)sender{
    imageView.frame=originFrame;
}
@end
