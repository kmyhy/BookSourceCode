//
//  ViewController.h
//  TimerRunLoopTest
//
//  Created by chen neng on 12-7-22.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController{
    CFRunLoopRef mRunLoopRef;
}
@property (retain, nonatomic) IBOutlet UITextView *textView;
- (IBAction)runAction:(id)sender;

@property (retain, nonatomic) IBOutlet UIButton *btn;
@end
void _timer(CFRunLoopTimerRef timer __unused, void *info);