//
//  ViewController.m
//  TimerRunLoopTest
//
//  Created by chen neng on 12-7-22.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController
@synthesize btn;
@synthesize textView;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [self setTextView:nil];
    [self setBtn:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (void)dealloc {
    [textView release];
    [btn release];
    [super dealloc];
}

-(void)myThreadMainMethod{
    CFRunLoopTimerRef timer;  
    CFRunLoopTimerContext timer_context={0, self, NULL, NULL, NULL};
    
    timer = CFRunLoopTimerCreate(NULL, CFAbsoluteTimeGetCurrent(), 2, 0, 0, _timer, &timer_context); 
    mRunLoopRef=CFRunLoopGetCurrent();
    CFRunLoopAddTimer( mRunLoopRef, timer, kCFRunLoopCommonModes);  
    
    CFRunLoopRun(); 
}
- (IBAction)runAction:(id)sender {
    
    if ([@"Run" isEqualToString:btn.titleLabel.text]) {
        [btn setTitle:@"Stop" forState:UIControlStateNormal];
        [NSThread detachNewThreadSelector:@selector(myThreadMainMethod) toTarget:self withObject:nil]; 
    }else{
        textView.text=nil;
        [btn setTitle:@"Run" forState:UIControlStateNormal];
        if ( mRunLoopRef )
            CFRunLoopStop( mRunLoopRef );
    }
}
-(void)addLog:(NSDate*)date{
    NSDateFormatter* df=[[[NSDateFormatter alloc]init]autorelease];
    [df setDateFormat:@"yyyy-MM-dd hh:mm:ss"];
    if (textView.text && textView.text.length>0) {
        textView.text=[NSString stringWithFormat:@"%@\n%@",textView.text,[df stringFromDate:date]];
    }else
        textView.text=[df stringFromDate:date];
    
    // Scroll  to the bottom of TextView
    NSRange range;
    range = NSMakeRange ([[textView text] length], 0);
    [textView scrollRangeToVisible:range];
}
@end
void _timer(CFRunLoopTimerRef timer __unused, void *info){
    id obj=(id)info;
    [obj performSelectorOnMainThread:@selector(addLog:) withObject:[NSDate date] waitUntilDone:NO];
}
