//
//  ViewController.h
//  dispatchSourceTest
//
//  Created by chen neng on 12-7-25.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import <UIKit/UIKit.h>
#define FILE_NAME @"0064.jpg"

@interface ViewController : UIViewController{
    NSMutableData* data;
}
@property (retain, nonatomic) IBOutlet UIButton *button;
@property (retain, nonatomic) IBOutlet UIImageView *imageView;

- (IBAction)loadAction:(id)sender;

@end
