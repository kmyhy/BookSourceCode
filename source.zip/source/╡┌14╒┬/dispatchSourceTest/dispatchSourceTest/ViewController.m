//
//  ViewController.m
//  dispatchSourceTest
//
//  Created by chen neng on 12-7-25.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController
@synthesize button;
@synthesize imageView;


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [self setButton:nil];

    [self setImageView:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (void)dealloc {
    [button release];
    [data release];
    [imageView release];
    [super dealloc];
}

-(void) asyncLoadImage:(NSString*)filename

{
    
    NSFileHandle *fh=[NSFileHandle fileHandleForReadingAtPath:filename];
    
    int fd=fh.fileDescriptor;
     
    if (fd == -1) return;
    
    
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    dispatch_source_t readSource = dispatch_source_create(DISPATCH_SOURCE_TYPE_READ,
                                                          
                                                          fd, 0, queue);
    
    if (!readSource)
    {
        [fh release];
        return;
     }
    dispatch_source_set_event_handler(readSource, ^{
        size_t estimated = dispatch_source_get_data(readSource) ;
        char* buffer = (char*)malloc(estimated);
        if (buffer)
        {
            ssize_t actual = read(fd, buffer, sizeof(buffer));
            [data appendBytes:buffer length:actual];
            free(buffer);
            if (data.length%1024==0) {
                dispatch_async(dispatch_get_main_queue(), ^{  
                    imageView.image=[UIImage imageWithData:data];
                });
            }
            if(abs(actual-estimated)==0){
                dispatch_async(dispatch_get_main_queue(), ^{  
                    imageView.image=[UIImage imageWithData:data];
                });
            }

        }
         
    });
    dispatch_source_set_cancel_handler(readSource, ^{
        [fh release];
    });
    dispatch_resume(readSource);

}
- (IBAction)loadAction:(id)sender {
    NSString* path=[[NSBundle mainBundle]resourcePath];
    path=[path stringByAppendingPathComponent:FILE_NAME];
    data=[[NSMutableData alloc]init];
    imageView.image=nil;
    [self asyncLoadImage:path];
}
@end
