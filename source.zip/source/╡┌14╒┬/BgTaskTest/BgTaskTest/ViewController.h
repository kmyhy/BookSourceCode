//
//  ViewController.h
//  BgTaskTest
//
//  Created by chen neng on 12-7-25.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (retain, nonatomic) IBOutlet UITextView *textView;
@property (retain, nonatomic) IBOutlet UITextField *timer;
-(void)Log:(NSString*)str;
-(void)setNow;
@end
