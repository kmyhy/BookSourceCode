//
//  ViewController.m
//  BgTaskTest
//
//  Created by chen neng on 12-7-25.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController
@synthesize textView;
@synthesize timer;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [self setTextView:nil];
    [self setTimer:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (void)dealloc {
    [textView release];
    [timer release];
    [super dealloc];
}
-(void)setNow{
    NSDateFormatter* df=[[[NSDateFormatter alloc]init]autorelease];
    [df setDateFormat:@"HH:mm:ss"];
    timer.text=[df stringFromDate:[NSDate date]];
    NSLog(@"%@",timer.text);
}
-(void)Log:(NSString*)str{
    NSDateFormatter* df=[[[NSDateFormatter alloc]init]autorelease];
    [df setDateFormat:@"HH:mm:ss"];
    NSString* string=[NSString stringWithFormat:@"%@%@",str,[df stringFromDate:[NSDate date]]];
    NSLog(@"%@",string);
    if (textView.text && textView.text.length>0) {
        textView.text=[NSString stringWithFormat:@"%@\n%@",textView.text,string];
    }else
        textView.text=string;
    // Scroll  to the bottom of TextView
    NSRange range;
    range = NSMakeRange ([[textView text] length], 0);
    [textView scrollRangeToVisible:range];
}
@end
