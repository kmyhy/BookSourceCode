//
//  ViewController.h
//  CGPathDemo
//
//  Created by chen neng on 12-5-19.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RoundRect.h"

@interface ViewController : UIViewController

@property (retain, nonatomic) IBOutlet UIButton *btDraw;
@property (retain, nonatomic) IBOutlet RoundRect *roundRect;

- (IBAction)drawAction:(id)sender;
@end
