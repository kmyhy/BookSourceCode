//
//  RoundRect.h
//  CGPathDemo
//
//  Created by chen neng on 12-5-19.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RoundRect : UIView
@property(assign,nonatomic)BOOL visible;

@end
