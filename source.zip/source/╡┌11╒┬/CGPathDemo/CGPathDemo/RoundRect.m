//
//  RoundRect.m
//  CGPathDemo
//
//  Created by chen neng on 12-5-19.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import "RoundRect.h"

@implementation RoundRect
@synthesize visible;
static void ContextAddRoundedRect(CGContextRef c, CGRect rect, CGFloat radius) {
    // 填充色：灰度0，透明度:0.4
    CGContextSetGrayFillColor(c, 0.0, 0.4);
    
    CGFloat minX = CGRectGetMinX(rect);
    CGFloat maxX = CGRectGetMaxX(rect);
    CGFloat minY = CGRectGetMinY(rect);
    CGFloat maxY = CGRectGetMaxY(rect);
    
    CGContextMoveToPoint(c, minX + radius, minY);
    CGContextAddArcToPoint(c, maxX, minY, maxX, minY + radius, radius);
    CGContextAddArcToPoint(c, maxX, maxY, maxX - radius, maxY, radius);
    CGContextAddArcToPoint(c, minX, maxY, minX, maxY - radius, radius);
    CGContextAddArcToPoint(c, minX, minY, minX + radius, minY, radius);
    CGContextFillPath(c);// 填充路径,自动关闭路径
}
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}
-(void)drawRect:(CGRect)rect{
    if(visible){
        CGSize size=self.frame.size;
        CGRect boxRect = CGRectMake(0, 0, size.width, size.height);
        float radius = 10.0f;
        CGContextRef context = UIGraphicsGetCurrentContext();
        ContextAddRoundedRect(context, boxRect, radius); 
    }
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
