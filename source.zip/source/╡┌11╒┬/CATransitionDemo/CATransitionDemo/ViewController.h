//
//  ViewController.h
//  CATransitionDemo
//
//  Created by chen neng on 12-5-20.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (retain, nonatomic) IBOutlet UIView *vwPage2;
- (IBAction)nextAction:(id)sender;

- (IBAction)returnAction:(id)sender;
@end
