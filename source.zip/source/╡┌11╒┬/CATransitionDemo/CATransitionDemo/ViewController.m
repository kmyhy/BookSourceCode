//
//  ViewController.m
//  CATransitionDemo
//
//  Created by chen neng on 12-5-20.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import "ViewController.h"
#import <QuartzCore/QuartzCore.h>

@implementation ViewController
@synthesize vwPage2;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [self setVwPage2:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (void)dealloc {
    [vwPage2 release];
    [super dealloc];
}
- (IBAction)nextAction:(id)sender {
    CATransition *transition = [CATransition animation];//1
	transition.type = @"pageCurl";//2
	transition.subtype = kCATransitionFromRight;//3
	transition.duration = 1.0f;//4
	transition.timingFunction = UIViewAnimationCurveEaseInOut;//5
    [self.view exchangeSubviewAtIndex:0 withSubviewAtIndex:1];//6
	// 设置转换动画
    [[self.view layer] addAnimation:transition forKey:@"pageCurlAnimation"];//7
}

- (IBAction)returnAction:(id)sender {
    [self nextAction:sender];
}
@end
