//
//  ViewController.m
//  GradientDemo
//
//  Created by chen neng on 12-5-19.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import "ViewController.h"
#import <QuartzCore/QuartzCore.h>

@implementation ViewController
@synthesize imageView;
@synthesize button;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)drawLinearGradientAction:(id)sender {
    CGGradientRef myGradient;
    CGColorSpaceRef myColorspace;
    size_t num_locations = 2;
    CGFloat locations[2] = { 0.0, 1.0 };
    CGFloat components[8] = { 1.0, 0.5, 0.4, 1.0,  //开始颜色
        0.8, 0.8, 0.3, 1.0 }; //终止颜色
    myColorspace = CGColorSpaceCreateDeviceRGB();//创建一个CGColorSpace对象
    myGradient = CGGradientCreateWithColorComponents (myColorspace, components,locations, num_locations);
    CGPoint myStartPoint, myEndPoint;// 开始点，结束点
    myStartPoint.x = 0.0;
    myStartPoint.y = 0.0;
    myEndPoint.x = imageView.frame.size.width;
    myEndPoint.y = imageView.frame.size.height;	
    
    UIGraphicsBeginImageContext(imageView.frame.size);
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextDrawLinearGradient (ctx, myGradient, myStartPoint, myEndPoint, 0);
    UIImage *resultImage = UIGraphicsGetImageFromCurrentImageContext();
    imageView.image=resultImage;
    UIGraphicsEndImageContext();

}
@end
