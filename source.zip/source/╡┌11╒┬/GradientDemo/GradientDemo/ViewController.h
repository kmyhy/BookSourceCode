//
//  ViewController.h
//  GradientDemo
//
//  Created by chen neng on 12-5-19.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (retain, nonatomic) IBOutlet UIButton *button;
- (IBAction)drawLinearGradientAction:(id)sender;
@property (retain, nonatomic) IBOutlet UIImageView *imageView;

@end
