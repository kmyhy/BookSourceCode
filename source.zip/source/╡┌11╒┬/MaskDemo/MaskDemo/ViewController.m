//
//  ViewController.m
//  MaskDemo
//
//  Created by chen neng on 12-5-19.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import "ViewController.h"

@implementation ViewController
@synthesize button;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createButtonImage];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [self setButton:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (void)dealloc {
    [button release];
    [super dealloc];
}
-(void)createButtonImage{
    // 从itemImage中获取按钮图片
	UIImage* rawButtonImage = [UIImage imageNamed:@"Icon.png"];
	// 将rawButtonImage与downImage合成一张图片。downImage为空时，制造一张灰色图片
	UIImage* buttonImage = [self doImageMask:rawButtonImage size:button.frame.size downImage:
                            [UIImage imageNamed:@"IconDeep.png"]];
	// downImage不为空，将制造一张rawButtonImage与downImage通过Mask合成的图片
	UIImage* buttonPressedImage = [self doImageMask:rawButtonImage size:button.frame.size downImage:[UIImage imageNamed:@"IconBase.png"]];
    
    // 将上述两张合成图片作为按钮的Normal和Select状态时的图片
	[button setImage:buttonImage forState:UIControlStateNormal];
	[button setImage:buttonPressedImage forState:UIControlStateHighlighted];
	[button setImage:buttonPressedImage forState:UIControlStateSelected];
}
// 使用遮罩技术，将两张图片进行合成
-(UIImage*)doImageMask:(UIImage*)upImage size:(CGSize)targetSize downImage:(UIImage*)downImage
{
	// 选中时，背景为蓝色，未选中时，背景为灰色
	UIImage* backgroundImage = [self createDownImage:upImage.size downImage:downImage];
	
	// 将上层图片转换为白色背景黑色前景（用于做遮罩）
	UIImage* bwImage = [self fillImageWhite:upImage];
	// 用黑白两色的upImage图片创建一个遮罩
	CGImageRef imageMask = CGImageMaskCreate(CGImageGetWidth(bwImage.CGImage),
											 CGImageGetHeight(bwImage.CGImage),
											 CGImageGetBitsPerComponent(bwImage.CGImage),
											 CGImageGetBitsPerPixel(bwImage.CGImage),
											 CGImageGetBytesPerRow(bwImage.CGImage),
											 CGImageGetDataProvider(bwImage.CGImage), NULL, YES);
	
	// 用这个遮罩和下层图片合成按钮图片
	CGImageRef compositeImageRef = CGImageCreateWithMask(backgroundImage.CGImage, imageMask);
	
	UIImage* compositeImage = [UIImage imageWithCGImage:compositeImageRef scale:upImage.scale 
										 orientation:upImage.imageOrientation];
	
	// Cleanup
	CGImageRelease(imageMask);
	CGImageRelease(compositeImageRef);
	
	// ==============重新开始绘制按钮图片==============
	UIGraphicsBeginImageContextWithOptions(targetSize, NO, 0.0);
	
	// 将按钮图片绘制在targetSize的中心对齐
	[compositeImage drawInRect:CGRectMake((targetSize.width/2.0) - (upImage.size.width/2.0), 
									   (targetSize.height/2.0) - (upImage.size.height/2.0), 
									   upImage.size.width, 
									   upImage.size.height)];
	
	// 将绘制的图片返回
	UIImage* resultImage = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
	
	return resultImage;
}
// 创建背景图片
-(UIImage*) createDownImage:(CGSize)size downImage:(UIImage*)downImage
{
	//=================开始 Core Graphics 绘图=================
	UIGraphicsBeginImageContextWithOptions(size, NO, 0.0);
	// 在上层图片的中心对齐绘制背景图片
    [downImage drawInRect:CGRectMake((size.width - CGImageGetWidth(downImage.CGImage)) / 2, 
                                     (size.height - CGImageGetHeight(downImage.CGImage)) / 2, 
                                     CGImageGetWidth(downImage.CGImage),
                                     CGImageGetHeight(downImage.CGImage))];
	
	UIImage* result = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
	//===================结束绘图===================
	return result;
}
// 将图片设置为白色背景，方便做遮罩
-(UIImage*) fillImageWhite:(UIImage*)originImage
{
	CGRect imageRect = CGRectMake(0, 0, CGImageGetWidth(originImage.CGImage), CGImageGetHeight(originImage.CGImage));
	
	// 创建位图上下文
	CGContextRef context = CGBitmapContextCreate(NULL, // 内存图片数据
												 imageRect.size.width, // 宽
												 imageRect.size.height, // 高
												 8, // 色深
												 0, // 每行字节数
												 CGImageGetColorSpace(originImage.CGImage), // 颜色空间
												 kCGImageAlphaPremultipliedLast); // alpha通道，RBGA
	// 设置当前上下文填充色为白色（RGBA值）
	CGContextSetRGBFillColor(context,1,1,1,1);
	CGContextFillRect(context,imageRect);
	
	// 用 originImage 作为 clipping mask（选区）
	CGContextClipToMask(context, imageRect, originImage.CGImage);
	// 设置当前填充色为黑色
	CGContextSetRGBFillColor(context, 0, 0, 0, 1);
	// 在clipping mask上填充黑色
	CGContextFillRect(context, imageRect);
	CGImageRef newCGImage = CGBitmapContextCreateImage(context);
	UIImage* newImage = [UIImage imageWithCGImage:newCGImage scale:originImage.scale orientation:originImage.imageOrientation];
	
	// Cleanup
	CGContextRelease(context);
	CGImageRelease(newCGImage);
	
	return newImage;
}

@end
