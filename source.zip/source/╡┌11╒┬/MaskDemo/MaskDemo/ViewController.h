//
//  ViewController.h
//  MaskDemo
//
//  Created by chen neng on 12-5-19.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (retain, nonatomic) IBOutlet UIButton *button;
-(void)createButtonImage;
-(UIImage*)doImageMask:(UIImage*)upImage size:(CGSize)targetSize downImage:(UIImage*)downImage;
-(UIImage*) createDownImage:(CGSize)size downImage:(UIImage*)downImage;
-(UIImage*) fillImageWhite:(UIImage*)originImage;

@end
