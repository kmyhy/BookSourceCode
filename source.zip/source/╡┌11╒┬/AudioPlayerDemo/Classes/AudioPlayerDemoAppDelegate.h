//
//  AudioPlayerDemoAppDelegate.h
//  AudioPlayerDemo
//
//  Created by chen neng on 11-10-7.
//  Copyright 2011 ydtf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface AudioPlayerDemoAppDelegate : NSObject
<UIApplicationDelegate,AVAudioPlayerDelegate> {
    UIWindow *window;
	AVAudioPlayer* player;
}
@property (retain, nonatomic) IBOutlet UILabel *lbTitle;

@property (nonatomic, retain) IBOutlet UIWindow *window;
-(IBAction)play;
-(IBAction)pause;

@end

