//
//  MovFileViewController.m
//  MoviePlayerDemo
//
//  Created by chen neng on 11-10-7.
//  Copyright 2011 ydtf. All rights reserved.
//

#import "MovFileViewController.h"


@implementation MovFileViewController

-(IBAction)loadVedio{
	NSString* path=[[NSBundle mainBundle]pathForResource:Mov_File
												  ofType:nil];
	
	NSURL *url = [NSURL fileURLWithPath:path];
	NSLog(@"url:%@",url);
	//使用MPMoviePlayerViewController而非MPMoviePlayerController
	player = [[MPMoviePlayerViewController alloc] initWithContentURL:url];
	//注册观察者,监听"播放完毕"消息
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(fileLoaded:) 
												 name:MPMediaPlaybackIsPreparedToPlayDidChangeNotification 
											   object:nil];
	[self presentMoviePlayerViewControllerAnimated:player];	
	
}
-(void)fileLoaded:(NSNotification *) notification {
	NSLog(@"%s",__FUNCTION__);
	// MPMediaPlayerViewController打开文件后会自动开始播放
	//[player.moviePlayer play];
}
/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[player release];
    [super dealloc];
}


@end
