//
//  MovFileViewController.h
//  MoviePlayerDemo
//
//  Created by chen neng on 11-10-7.
//  Copyright 2011 ydtf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#define Mov_File @"daomengkongjian.mp4"

@interface MovFileViewController : UIViewController {
	MPMoviePlayerViewController *player ;
}
-(IBAction)loadVedio;
@end
