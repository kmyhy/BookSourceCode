//
//  ViewController.m
//  TransformDemo
//
//  Created by chen neng on 12-5-19.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import "ViewController.h"
#import <math.h>

@implementation ViewController
@synthesize imageView;


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [self setImageView:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

- (void)dealloc {
    [imageView release];
    [super dealloc];
}
- (IBAction)rotateAction:(id)sender {
    UIImage* image=[UIImage imageNamed:@"未命名.png"];
    CGImageRef img = [image CGImage];
    CGFloat width = CGImageGetWidth(img);
    CGFloat height = CGImageGetHeight(img);
    CGSize size = CGSizeMake(width, height);
    CGRect bounds = CGRectMake(0, 0, width, height);

    CGAffineTransform transform = CGAffineTransformIdentity;
    transform = CGAffineTransformMakeTranslation(height, 0.0f);
    transform = CGAffineTransformRotate(transform, M_PI / 2.0f);
    CGFloat origHeight = size.height;
    size.height = size.width;
    size.width = origHeight;
    CGSize newSize = size;
    
    UIGraphicsBeginImageContext(newSize);
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    CGContextConcatCTM(ctx, transform);
    // 绘制图形
    CGContextDrawImage (ctx, bounds, img);
    // 将绘制的图应用到ImageView
    imageView.image=UIGraphicsGetImageFromCurrentImageContext();
}
@end
