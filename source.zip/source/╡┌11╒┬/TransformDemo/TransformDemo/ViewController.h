//
//  ViewController.h
//  TransformDemo
//
//  Created by chen neng on 12-5-19.
//  Copyright (c) 2012年 ydtf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (retain, nonatomic) IBOutlet UIImageView *imageView;
- (IBAction)rotateAction:(id)sender;

@end
