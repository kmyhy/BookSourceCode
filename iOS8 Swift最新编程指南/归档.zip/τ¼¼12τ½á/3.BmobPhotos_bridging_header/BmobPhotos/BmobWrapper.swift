//
//  BmobWrapper.swift
//  BmobPhotos
//
//  Created by yanghongyan on 14/12/7.
//  Copyright (c) 2014年 yanghongyan. All rights reserved.
//

import Foundation

let AppKey = "<YOUR BMOB APP KEY>"

func registerBmob(){
    Bmob.registerWithAppKey(AppKey)
}