//
//  Label.swift
//  UITraitEnvironmentDemo
//
//  Created by yanghongyan on 14-10-17.
//  Copyright (c) 2014年 yanghongyan. All rights reserved.
//

import UIKit

class Label: UILabel {
    var verticalPadding = 0.0
    override func traitCollectionDidChange(previousTraitCollection: UITraitCollection?) {
        
        if traitCollection.verticalSizeClass == .Compact {
        verticalPadding = 0.0
    } else {
        
        verticalPadding = 20.0
        }
        invalidateIntrinsicContentSize()
    }
    override func intrinsicContentSize() -> CGSize {
            var intrinsicSize = super.intrinsicContentSize() // Add the padding
            intrinsicSize.height += CGFloat(verticalPadding)
            return intrinsicSize
    }
}