//
//  ThumbnailSelection.swift
//  PhotoGalleryStarter
//
//  Created by yanghongyan on 14-10-16.
//  Copyright (c) 2014年 yanghongyan. All rights reserved.
//

import Foundation
import AssetsLibrary

@objc protocol ThumbnailSelectionDelegate {
    func didSelect(asset: ALAsset, sender: AnyObject?)
}
@objc protocol ThumbnailSelector {
    var delegate: ThumbnailSelectionDelegate? { get set }
}
@objc protocol PhotoPreviewer {
    var asset: ALAsset? { get set }
}