//
//  ViewController.swift
//  PhotoGalleryStarter
//
//  Created by yanghongyan on 14-10-16.
//  Copyright (c) 2014年 yanghongyan. All rights reserved.
//

import UIKit
import AssetsLibrary

class ViewController: UIViewController,ThumbnailSelectionDelegate {

    @IBOutlet var tallConstraints: [NSLayoutConstraint]!

    @IBOutlet var shortConstraints: [NSLayoutConstraint]!
    override func viewDidLoad() {
        super.viewDidLoad()
        for viewController in childViewControllers as [UIViewController] {
            if let selector = viewController as? ThumbnailSelector {
                selector.delegate = self
            }
        }
    }

    func didSelect(asset: ALAsset, sender: AnyObject?) {
        for viewController in childViewControllers as [UIViewController] {
            if let viewer = viewController as? PhotoPreviewer {
                viewer.asset = asset
            }
        }
    }
    override func supportedInterfaceOrientations() -> Int {
        return Int(UIInterfaceOrientationMask.All.rawValue)
    }
    
    override func viewWillTransitionToSize(size: CGSize,withTransitionCoordinator coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransitionToSize(size, withTransitionCoordinator: coordinator)
        let transitionToWide = size.width > size.height
        let constraintsToUninstall = transitionToWide ? tallConstraints : shortConstraints
        let constraintsToInstall = transitionToWide ? shortConstraints : tallConstraints
        // Ask Auto Layout to commit any outstanding changes
        view.layoutIfNeeded()
        // Animate to the new layout alongside the transition
        coordinator.animateAlongsideTransition({
            _ in
            NSLayoutConstraint.deactivateConstraints(constraintsToUninstall)
            NSLayoutConstraint.activateConstraints(constraintsToInstall)
            
            },
            completion: {
            _ in
            self.view.layoutIfNeeded()
            })
    }
    
}

