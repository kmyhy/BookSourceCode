//
//  ThumbnailCollectionVC.swift
//  PhotoGalleryStarter
//
//  Created by yanghongyan on 14-10-16.
//  Copyright (c) 2014年 yanghongyan. All rights reserved.
//

import UIKit
import AssetsLibrary

let reuseIdentifier = "Cell"

class ThumbnailCollectionVC: UICollectionViewController,ThumbnailSelector {

    var assetLibrary : ALAssetsLibrary = ALAssetsLibrary()
    var assetList: Array<ALAsset>?
    var delegate: ThumbnailSelectionDelegate?
    var currentCellContentTransform = CGAffineTransformIdentity
    // Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        if let flowLayout = collectionViewLayout as?
            UICollectionViewFlowLayout {
            let minDimension = min(CGRectGetHeight(view.bounds),
            CGRectGetWidth(view.bounds))
            let newItemSize = CGSize(width: minDimension,height: minDimension)
            if flowLayout.itemSize != newItemSize {
            flowLayout.itemSize = newItemSize
            flowLayout.invalidateLayout()
            }
        }
    }
    
    override func viewWillAppear(animated: Bool) {
        if assetList == nil {
            self.loadAssetsGroups()
        }
    }
    private func loadAssetsGroups(){
        assetList = []
        self.assetLibrary = ALAssetsLibrary()
        var count = 0
        var countOne = 0
        let assetsType : ALAssetsGroupType = 0xFFFFFFFF//Int(ALAssetsGroupAll)
        
        var groupBlock : ALAssetsLibraryGroupsEnumerationResultsBlock = {
            
            (group: ALAssetsGroup!, stop: UnsafeMutablePointer<ObjCBool>) in
            println("is goin")
            if group != nil
            {
                count++
                var assetBlock : ALAssetsGroupEnumerationResultsBlock = {
                    (result: ALAsset!, index: Int, stop: UnsafeMutablePointer<ObjCBool>) in
                    if result != nil {
//                        println(result.description)
                        self.assetList?.append(result)
                        self.collectionView?.reloadData()
//                        println(assetsArray)
                        countOne++
                    }
                }
                group.enumerateAssetsUsingBlock(assetBlock)
                
            }
        }
        var groupFailureBlock : ALAssetsLibraryAccessFailureBlock = {
            (NSError) in
            println("error")
            
        }
        assetLibrary.enumerateGroupsWithTypes(assetsType, usingBlock: groupBlock, failureBlock: groupFailureBlock)

    }
    
    // #pragma mark UICollectionViewDataSource
    override func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 1
    }
    
    override func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if let list = assetList {
            return list.count
        }
        return 0
    }
    
    override func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier(reuseIdentifier, forIndexPath: indexPath) as UICollectionViewCell
        // Configure the cell
        if let thumbnailCell = cell as? CollectionViewCell {
            if let asset = assetList?[indexPath.item] {
                thumbnailCell.resetCell(asset)
            }
        }
        return cell
    }
    
    // #pragma mark <UICollectionViewDelegate>
    override func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        if let asset = assetList?[indexPath.item] {
            delegate?.didSelect(asset, sender: self)
        }
    }
    override func collectionView(collectionView: UICollectionView, willDisplayCell cell: UICollectionViewCell, forItemAtIndexPath indexPath: NSIndexPath) {
            cell.contentView.transform = currentCellContentTransform
    }
    // UIViewController
    override func viewWillTransitionToSize(size: CGSize, withTransitionCoordinator coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransitionToSize(size, withTransitionCoordinator: coordinator)
        // 1
        let targetTForm = coordinator.targetTransform()
        let inverseTForm = CGAffineTransformInvert(targetTForm) // 2
        coordinator.animateAlongsideTransition({ _ in
        // Empty
        }, completion: { _ in // 3
        self.view.layer.transform = CATransform3DConcat(self.view.layer.transform, CATransform3DMakeAffineTransform(inverseTForm))
        // 4
        if abs(atan2(Double(targetTForm.b), Double(targetTForm.a)) / M_PI) < 0.9 {
        self.view.bounds = CGRect(x: 0, y: 0,
        width: self.view.bounds.size.height,
        height: self.view.bounds.size.width) }
        // 5
        self.currentCellContentTransform = CGAffineTransformConcat(self.currentCellContentTransform, targetTForm)
        UIView.animateWithDuration(0.5, delay: 0, usingSpringWithDamping: 0.6, initialSpringVelocity: 1, options: nil, animations: {
            for cell in self.collectionView?.visibleCells() as [UICollectionViewCell] {
            cell.contentView.transform = self.currentCellContentTransform
            }
            }, completion: nil)
        })
    }

}
