//
//  CollectionViewCell.swift
//  PhotoGalleryStarter
//
//  Created by yanghongyan on 14-10-16.
//  Copyright (c) 2014年 yanghongyan. All rights reserved.
//

import UIKit
import AssetsLibrary

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    
    func resetCell(asset:ALAsset) {
        
        imageView.image = UIImage(CGImage: asset.thumbnail().takeUnretainedValue())
    }
}
