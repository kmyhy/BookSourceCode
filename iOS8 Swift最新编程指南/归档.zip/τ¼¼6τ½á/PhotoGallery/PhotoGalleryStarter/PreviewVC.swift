//
//  PreviewVC.swift
//  PhotoGalleryStarter
//
//  Created by yanghongyan on 14-10-16.
//  Copyright (c) 2014年 yanghongyan. All rights reserved.
//

import UIKit
import AssetsLibrary

class PreviewVC: UIViewController,PhotoPreviewer {
    
    var asset: ALAsset?{
        didSet {
            var assetRep = asset?.defaultRepresentation()
            if let iref = assetRep?.fullResolutionImage().takeUnretainedValue() {
                var image = UIImage(CGImage: iref)
                imageView.image = image
            }
        }
    }

    @IBOutlet weak var imageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
