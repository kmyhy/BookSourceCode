//
//  PopupVC.swift
//  VisualEffects
//
//  Created by yanghongyan on 15/1/29.
//  Copyright (c) 2015年 yanghongyan. All rights reserved.
//

import UIKit

class PopupVC: UIViewController {
//    var blurView : UIVisualEffectView!
    @IBOutlet weak var contentView: UIView!

    @IBOutlet weak var leftButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}
