//
//  ViewController.swift
//  Weather
//
//  Created by yanghongyan on 14/11/4.
//  Copyright (c) 2014年 yanghongyan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var tfCityname: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func save(sender: AnyObject) {
        
        tfCityname.resignFirstResponder()
        
        if tfCityname.text != nil && countElements(tfCityname.text)>0 {
            if let cityCode = getCityCode(self.tfCityname.text){
                saveStringToShareContainer("citycode", cityCode)
                return
            }
        }
        tfCityname.placeholder = "没有这个城市";
        tfCityname.text = nil;
    }

}

