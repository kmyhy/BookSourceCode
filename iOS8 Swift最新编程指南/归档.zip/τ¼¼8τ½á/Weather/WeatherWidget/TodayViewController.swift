//
//  TodayViewController.swift
//  WeatherWidget
//
//  Created by yanghongyan on 14/11/5.
//  Copyright (c) 2014年 yanghongyan. All rights reserved.
//

import UIKit
import NotificationCenter

class TodayViewController: UIViewController, NCWidgetProviding {
        
    @IBOutlet weak var lbHumidity: UILabel!
    @IBOutlet weak var lbWindSpeed: UILabel!
    @IBOutlet weak var lbCity: UILabel!
    @IBOutlet weak var lbTemp: UILabel!
    @IBOutlet weak var lbTime: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.preferredContentSize = CGSizeMake(self.view.frame.size.width, 110)
    }
    override func viewWillAppear(animated: Bool)
    {
        super.viewWillAppear(animated)
        
        refresh();
    }
    @IBAction func refresh() {
        if let cityCode = readStringFromShareContainer("citycode"){
            weatherInfo(cityCode, { (json) -> Void in
                let city = getStringForWeatherInfo("city", json)
                let temp = getStringForWeatherInfo("temp", json)
                let time = getStringForWeatherInfo("time", json)
                let WS = getStringForWeatherInfo("WS", json)
                let SD = getStringForWeatherInfo("SD", json)
                self.lbCity.text = city
                self.lbTemp.text = temp
                self.lbTime.text = time
                self.lbWindSpeed.text = WS == nil ? nil : "风力" + WS!
                self.lbHumidity.text = SD == nil ? nil : "湿度" + SD!
            })
            return
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func widgetPerformUpdateWithCompletionHandler(completionHandler: ((NCUpdateResult) -> Void)!) {
        completionHandler(NCUpdateResult.NewData)
    }
    func widgetMarginInsetsForProposedMarginInsets(defaultMarginInsets: UIEdgeInsets) -> (UIEdgeInsets)
    {
        return UIEdgeInsetsZero
    }
}
