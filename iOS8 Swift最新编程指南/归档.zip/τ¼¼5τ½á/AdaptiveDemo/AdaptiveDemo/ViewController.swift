//
//  ViewController.swift
//  AdaptiveDemo
//
//  Created by chen neng on 14-10-1.
//  Copyright (c) 2014年 kmyhy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

