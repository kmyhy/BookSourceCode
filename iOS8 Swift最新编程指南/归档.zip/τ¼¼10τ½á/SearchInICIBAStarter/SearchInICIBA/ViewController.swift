//
//  ViewController.swift
//  SearchInICIBA
//
//  Created by yanghongyan on 14/11/20.
//  Copyright (c) 2014年 yanghongyan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var textField: UITextField!

    @IBOutlet weak var webView: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func searchAction(sender: AnyObject) {

    }
    @IBAction func backAction(sender: AnyObject) {
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

