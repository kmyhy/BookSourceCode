var styleNode = document.createElement("style");
styleNode.textContent = 'div.nv_i {display: none} ';
document.documentElement.appendChild(styleNode);