//
//  Constants.swift
//  HandOffNote
//
//  Created by yanghongyan on 15/1/26.
//  Copyright (c) 2015年 yanghongyan. All rights reserved.
//

import Foundation

let ActivityTypeView = "com.ydtf.HandOffNote.view"
let ActivityTypeEdit = "com.ydtf.HandOffNote.edit"