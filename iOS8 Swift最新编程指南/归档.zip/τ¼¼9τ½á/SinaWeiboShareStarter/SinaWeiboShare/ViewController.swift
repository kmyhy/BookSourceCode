//
//  ViewController.swift
//  SinaPhotoShare
//
//  Created by yanghongyan on 14/11/8.
//  Copyright (c) 2014年 yanghongyan. All rights reserved.
//

import UIKit

class ViewController: UIViewController{
    @IBOutlet weak var imageView: UIImageView!
    @IBAction func sharePhoto(sender: AnyObject) {}
    override func viewDidLoad() {
    }

 }

