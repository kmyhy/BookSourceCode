import Alamofire
import UIKit

let appKey = "1062363663"
let redirectURI = "http://d.91dingdong.com/"
let sinaSecret  = "90476c816329463b6aba87a3d3cf2342"

let groupName = "group.ydtf.TodayExtension"
let defaults =  NSUserDefaults(suiteName: groupName)

let storeKey = "SinaWeiboAuthData"
let AccessTokenKey = "WeiBoAccessToken"
let ExpirationDateKey = "WeiBoExpirationDate"
let UserIDKey = "WeiBoUserID"
let RefreshTokenKey = "WeiBoRefreshToken"

let BodyStringBoundary = "293iosfksdfkiowjksdf31jsiuwq003s02dsaffafass3qw"

func postImage(image:UIImage,text:String,completion:(NSDictionary)->Void,exception:(NSError)->Void)->Void{
    var urlString = "https://open.weibo.cn/2/statuses/upload.json"
    
    let data = UIImagePNGRepresentation(image)
    if let url = NSURL(string:urlString){
        
        var params:Dictionary<String,AnyObject> = [:]
        params["access_token"] = access_token()
        params["status"] = text
        params["pic"] = data
        
        urlString = serializeURL(urlString, params, "POST")
        
        let request = NSMutableURLRequest(URL: NSURL(string:urlString)!)
        request.HTTPMethod = "POST"
        
        request.HTTPBody = postBody(params)
        let contentType = "multipart/form-data; boundary=\(BodyStringBoundary)"
        
        request.setValue(contentType, forHTTPHeaderField: "Content-Type")
        
        Alamofire.request(request).responseJSON{
            (_, _, JSON, error) in
            if error == nil {
                if let info = JSON as? NSDictionary
                {
                    completion(info)
                }
            }else{
                exception(error!)
            }
        }
    }
    
}
func access_token()->String!{
    if let dic = defaults?.dictionaryForKey(storeKey) {
        return dic[AccessTokenKey] as? String
    }
    return nil
}
func serializeURL(baseURL:String,params:NSDictionary,httpMethod:String)->String
{
    let parsedURL = NSURL(string:baseURL)
    let queryPrefix = (parsedURL!.query != nil) ? "&" : "?";
    
    var pairs = NSMutableArray()
    for key in params.allKeys {
        let k = key as String
        if params.valueForKey(k) is NSData {
            continue;
        }
        
        var escaped_value = params.objectForKey(k) as? String
        
        escaped_value = escaped_value?.stringByAddingPercentEscapesUsingEncoding(NSUTF8StringEncoding)
        
        pairs.addObject("\(k)=\(escaped_value!)")
    }
    let query = pairs.componentsJoinedByString("&")
    
    return "\(baseURL)\(queryPrefix)\(query)"
}
func appendUTF8Body(body:NSMutableData, dataString:String)
{
    body.appendData(dataString.dataUsingEncoding(NSUTF8StringEncoding)!)
}
func postBody(params:NSDictionary)->NSData{
    let bodyPrefixString = "--\(BodyStringBoundary)\r\n"
    
    let bodySuffixString = "\r\n--\(BodyStringBoundary)--\r\n"
    
    var dataDictionary = NSMutableDictionary()
    
    var body = NSMutableData()
    
    appendUTF8Body(body, bodyPrefixString)
    
    for key in params.allKeys {
        let k = key as String
        if params.valueForKey(k) is NSData {
            dataDictionary.setObject(params.valueForKey(k)!, forKey: k)
            continue
        }
        
        appendUTF8Body(body, "Content-Disposition: form-data; name=\"\(k)\"\r\n\r\n\(params.valueForKey(k)!)\r\n")
        appendUTF8Body(body,bodyPrefixString)
    }
    
    for key in dataDictionary.allKeys{
        let k = key as String
        let dataParam: AnyObject? = dataDictionary.valueForKey(k)
        if let obj = dataParam as? NSData{
            appendUTF8Body(body, "Content-Disposition: form-data; name=\"\(k)\"; filename=\"file\"\r\n")
            appendUTF8Body(body, "Content-Type: content/unknown\r\nContent-Transfer-Encoding: binary\r\n\r\n")
            body.appendData(obj)
        }
        appendUTF8Body(body, bodySuffixString)
    }
    return body;
}
