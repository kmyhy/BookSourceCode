//
//  ViewController.swift
//  SinaPhotoShare
//
//  Created by yanghongyan on 14/11/8.
//  Copyright (c) 2014年 yanghongyan. All rights reserved.
//

import UIKit

class ViewController: UIViewController,SinaWeiboDelegate{
    var sinaWeibo:SinaWeibo? = nil
    @IBOutlet weak var imageView: UIImageView!
    @IBAction func sharePhoto(sender: AnyObject) {
        if sinaWeibo != nil && sinaWeibo?.isLoggedIn() == false{
            sinaWeibo?.logIn()
        }else{
            
            var alert = UIAlertController(title:nil, message:"分享至新浪微博", preferredStyle:UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "取消", style: UIAlertActionStyle.Default, handler: {(alert :UIAlertAction!) in
            }))
            alert.addAction(UIAlertAction(title: "分享", style: UIAlertActionStyle.Default, handler: {(alert :UIAlertAction!) in
                
                postImage(UIImage(named: "share")!, "分享测试", { (string) -> Void in
                    self.shareSuccess(string)
                    }, { (error) -> Void in
                        self.shareFail(error)
                })
            }))
            alert.addAction(UIAlertAction(title: "退出登录", style: UIAlertActionStyle.Default, handler: {(alert :UIAlertAction!) in
                self.sinaWeibo?.logOut()
                return // It's necessary or else yield errors,why?
            }))
            self.presentViewController(alert, animated: true, completion: nil)
            
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        sinaWeibo = SinaWeibo(appKey: appKey, appSecret: sinaSecret, appRedirectURI: redirectURI, andDelegate: self)
    }
    
    func shareSuccess(string:NSDictionary){
        println(string)
        var alert = UIAlertController(title:nil, message:"内容成功发送到微博！", preferredStyle:UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "确定", style: UIAlertActionStyle.Default, handler: {(alert :UIAlertAction!) in
        }))
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    func shareFail(error:NSError){
        var failDescription = "请重试！";
        if (20019 == error.code)
        {
            failDescription = "重复发送了相同的内容！"
        }
        var alert = UIAlertController(title:"发送失败", message:failDescription, preferredStyle:UIAlertControllerStyle.Alert)
        alert.addAction(UIAlertAction(title: "确定", style: UIAlertActionStyle.Default, handler: {(alert :UIAlertAction!) in
        }))
        self.presentViewController(alert, animated: true, completion: nil)
    }

    
    // MARK: - SinaWeiboDelegate Delegate
    func sinaweibo(sinaweibo: SinaWeibo!, accessTokenInvalidOrExpired error: NSError!) {
        sinaWeiboRemoveAuthData()
    }
    func sinaweiboDidLogIn(sinaweibo: SinaWeibo!) {
        sinaWeiboStoreAuthData()
    }
    func sinaweiboDidLogOut(sinaweibo: SinaWeibo!) {
        sinaWeiboRemoveAuthData()
    }
    // MARK: - private
    func sinaWeiboRemoveAuthData()
    {
        defaults?.removeObjectForKey(storeKey)
        sinaWeibo?.removeAuthData()
    }
    func sinaWeiboStoreAuthData()
    {
        var authData = NSMutableDictionary()
        authData.setValue(sinaWeibo?.accessToken, forKey: AccessTokenKey)
        authData.setValue(sinaWeibo?.expirationDate, forKey: ExpirationDateKey)
        authData.setValue(sinaWeibo?.userID, forKey: UserIDKey)
        authData.setValue(sinaWeibo?.refreshToken, forKey: RefreshTokenKey)
        
        defaults?.setObject(authData, forKey: storeKey)
        defaults?.synchronize()
    }
    
 }

