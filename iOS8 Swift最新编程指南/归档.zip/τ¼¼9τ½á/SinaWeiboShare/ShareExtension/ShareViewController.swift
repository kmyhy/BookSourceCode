//
//  ShareViewController.swift
//  ShareExtension
//
//  Created by yanghongyan on 14/11/13.
//  Copyright (c) 2014年 yanghongyan. All rights reserved.
//

import UIKit
import Social
import MobileCoreServices

class ShareViewController: SLComposeServiceViewController {

    var imageToShare: UIImage?
    
    override func viewDidLoad() { // 1
        let items = extensionContext?.inputItems
        var itemProvider: NSItemProvider?
        // 2
        if items != nil && items!.isEmpty == false {
            let item = items![0] as NSExtensionItem
            if let attachments = item.attachments {
                if !attachments.isEmpty { // 3
                    itemProvider = attachments[0] as? NSItemProvider
                }
            }
        }
        // 4
        let imageType = kUTTypeImage as NSString as String
        if itemProvider?.hasItemConformingToTypeIdentifier(imageType) == true{
            // 5
            itemProvider?.loadItemForTypeIdentifier(imageType, options: nil){
                item, error in
                if error == nil {
                    // 6
                    let url = item as NSURL
                    if let imageData = NSData(contentsOfURL: url){
                        self.imageToShare = UIImage(data: imageData)
                    }
                } else {
                    // 7
                    let title = "无法加载图片"
                    let message = "请重试"
                    let alert = UIAlertController(title: title, message: message,preferredStyle: .Alert)
                    let action = UIAlertAction(title: "关闭", style:.Cancel)
                        { _ in
                            self.dismissViewControllerAnimated(true, completion: nil)
                    }
                    alert.addAction(action)
                    self.presentViewController(alert, animated: true,
                        completion: nil)
                }
                
            }
        }
    }
    
    override func isContentValid() -> Bool {
        return imageToShare != nil
    }

    override func didSelectPost() {
        var string = "来自Share Extension的分享"
        if contentText != nil {
            string = contentText!
        }
        postImage(self.imageToShare!, string, { (json) -> Void in
            if let url = json["original_pic"] as? String {
                UIPasteboard.generalPasteboard().string = url
                println("Shared success:\(url)")
            }
            },{ (error) -> Void in
                println(error.description)
        })
        
        self.extensionContext!.completeRequestReturningItems([], completionHandler:nil)
    }


    override func configurationItems() -> [AnyObject]! {
        let configItem = SLComposeSheetConfigurationItem()
        configItem.title = "分享成功后URL将拷贝至剪贴板"
        return [configItem]
    }

}
